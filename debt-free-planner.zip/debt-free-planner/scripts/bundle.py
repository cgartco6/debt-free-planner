#!/usr/bin/env python3
"""
scripts/bundle.py
=================
Builds a zero-dependency, single-file dist/index.html by:
  1. Reading all JS modules in dependency order
  2. Stripping import/export statements (converting to plain script)
  3. Inlining both CSS files
  4. Fetching Chart.js from CDN and inlining it (optional --offline flag)
  5. Writing dist/index.html

Usage:
    python scripts/bundle.py              # inline Chart.js from CDN via urllib
    python scripts/bundle.py --no-chartjs # skip Chart.js (assumes CDN at runtime)
    python scripts/bundle.py --offline    # alias for default (Chart.js fetched once)
"""

import os
import re
import sys
import textwrap
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"

# ── JS files in strict dependency order ────────────────────────────────────
JS_ORDER = [
    "src/utils/format.js",
    "src/engine/budgetEngine.js",
    "src/engine/debtEngine.js",
    "src/engine/savingsEngine.js",
    "src/engine/phaseEngine.js",
    "src/state.js",
    "src/views/wizard.js",
    "src/views/dashboard.js",
    "src/main.js",
]

CSS_ORDER = [
    "styles/main.css",
    "styles/dashboard.css",
]

CHARTJS_CDN = (
    "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"
)

GOOGLE_FONTS_CSS = (
    "https://fonts.googleapis.com/css2?"
    "family=Inter:wght@300;400;500;600;700;800"
    "&family=JetBrains+Mono:wght@400;500;600&display=swap"
)


def strip_modules(source: str, filename: str) -> str:
    """Remove ES module import/export syntax, keeping all logic intact."""
    lines = source.splitlines()
    out = []
    skip_import_block = False

    for line in lines:
        stripped = line.strip()

        # Skip single-line imports: import { ... } from '...'
        if re.match(r"^import\s+.*\s+from\s+['\"]", stripped):
            continue
        # Skip: import '...'
        if re.match(r"^import\s+['\"]", stripped):
            continue

        # Remove export keyword from declarations but keep the declaration
        # export function foo  →  function foo
        # export const foo     →  const foo
        # export class Foo     →  class Foo
        # export default xxx   →  (keep the value, drop 'export default')
        line = re.sub(
            r"^(\s*)export\s+default\s+",
            r"\1// export default: ",
            line,
        )
        line = re.sub(
            r"^(\s*)export\s+(function|class|const|let|var|async\s+function)\b",
            r"\1\2",
            line,
        )
        # Standalone 'export { ... }' lines — drop entirely
        if re.match(r"^\s*export\s*\{[^}]*\}\s*;?\s*$", line):
            continue

        out.append(line)

    banner = f"// ── {filename} {'─' * max(1, 60 - len(filename))}"
    return banner + "\n" + "\n".join(out)


def fetch_url(url: str, label: str) -> str:
    print(f"  Fetching {label}...")
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            return r.read().decode("utf-8")
    except Exception as e:
        print(f"  ⚠  Could not fetch {label}: {e}")
        return ""


def build(inline_chartjs: bool = True) -> None:
    DIST.mkdir(exist_ok=True)

    # ── Bundle CSS ─────────────────────────────────────────────────────────
    print("📦 Bundling CSS...")
    css_parts = []
    for rel in CSS_ORDER:
        path = ROOT / rel
        print(f"  {rel}")
        css_parts.append(f"/* ── {rel} ── */\n" + path.read_text(encoding="utf-8"))
    combined_css = "\n\n".join(css_parts)

    # ── Bundle JS ──────────────────────────────────────────────────────────
    print("📦 Bundling JS...")
    js_parts = []
    for rel in JS_ORDER:
        path = ROOT / rel
        print(f"  {rel}")
        source = path.read_text(encoding="utf-8")
        js_parts.append(strip_modules(source, rel))
    combined_js = "\n\n".join(js_parts)

    # ── Chart.js ───────────────────────────────────────────────────────────
    chartjs_tag = ""
    if inline_chartjs:
        chartjs_src = fetch_url(CHARTJS_CDN, "Chart.js 4.4.1")
        if chartjs_src:
            chartjs_tag = f"<script>\n{chartjs_src}\n</script>"
        else:
            chartjs_tag = (
                f'<script src="{CHARTJS_CDN}" crossorigin="anonymous"></script>'
            )
    else:
        chartjs_tag = (
            f'<script src="{CHARTJS_CDN}" crossorigin="anonymous"></script>'
        )

    # ── Assemble HTML ──────────────────────────────────────────────────────
    print("📄 Writing dist/index.html...")
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Income-first debt payoff planner. Real numbers, real plan, no lectures." />
  <meta name="theme-color" content="#0D1B2A" />
  <title>DebtFree Planner</title>
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔓</text></svg>" />

  <!-- Google Fonts (requires internet; omit for true offline) -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="{GOOGLE_FONTS_CSS}" rel="stylesheet" />

  <!-- Chart.js -->
  {chartjs_tag}

  <!-- Bundled CSS -->
  <style>
{textwrap.indent(combined_css, '    ')}
  </style>
</head>
<body>
  <div id="app"></div>

  <!-- Bundled JS (ES modules converted to plain script) -->
  <script>
{textwrap.indent(combined_js, '    ')}
  </script>
</body>
</html>
"""

    out_path = DIST / "index.html"
    out_path.write_text(html, encoding="utf-8")

    size_kb = out_path.stat().st_size / 1024
    print(f"\n✅ dist/index.html built successfully ({size_kb:.1f} KB)")
    print(f"   Open file://{out_path} in your browser, or serve with:")
    print(f"   python -m http.server 3000 --directory dist/")


if __name__ == "__main__":
    inline = "--no-chartjs" not in sys.argv
    build(inline_chartjs=inline)
