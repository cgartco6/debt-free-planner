#!/usr/bin/env bash
# =============================================================================
# scripts/deploy.sh — Interactive deployment script for DebtFree Planner
#
# Usage:
#   chmod +x scripts/deploy.sh
#   ./scripts/deploy.sh                  # interactive menu
#   ./scripts/deploy.sh vercel           # deploy to Vercel directly
#   ./scripts/deploy.sh netlify          # deploy to Netlify directly
#   ./scripts/deploy.sh render           # deploy to Render directly
#   ./scripts/deploy.sh streamlit        # prepare + instructions for Streamlit
#   ./scripts/deploy.sh build            # just build the bundle
#   ./scripts/deploy.sh local            # serve locally
# =============================================================================

set -e  # exit on error

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}ℹ  $*${RESET}"; }
success() { echo -e "${GREEN}✅ $*${RESET}"; }
warn()    { echo -e "${YELLOW}⚠  $*${RESET}"; }
error()   { echo -e "${RED}❌ $*${RESET}"; exit 1; }
header()  { echo -e "\n${BOLD}${CYAN}── $* ─────────────────────────────${RESET}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"

# ── Helper: check command exists ──────────────────────────────────────────────
need() {
  if ! command -v "$1" &>/dev/null; then
    error "'$1' not found. Install it first: $2"
  fi
}

# ── Build bundle ──────────────────────────────────────────────────────────────
build_bundle() {
  header "Building standalone bundle"
  cd "$ROOT"

  if command -v python3 &>/dev/null; then
    PY=python3
  elif command -v python &>/dev/null; then
    PY=python
  else
    error "Python not found. Install Python 3.8+ from https://python.org"
  fi

  $PY scripts/bundle.py --no-chartjs
  success "dist/index.html ready ($(du -sh dist/index.html | cut -f1))"
}

# ── Local serve ───────────────────────────────────────────────────────────────
deploy_local() {
  header "Local development server"
  cd "$ROOT"

  if command -v npm &>/dev/null && [ -f package.json ]; then
    info "Starting via npm (ES module mode — source files)"
    npm install --silent 2>/dev/null || true
    npm start
  elif command -v python3 &>/dev/null; then
    build_bundle
    info "Serving dist/ on http://localhost:3000"
    python3 -m http.server 3000 --directory dist/
  else
    error "Need Node.js or Python 3 to run a local server"
  fi
}

# ── Vercel ────────────────────────────────────────────────────────────────────
deploy_vercel() {
  header "Deploying to Vercel"
  need vercel "npm install -g vercel"
  cd "$ROOT"

  info "Vercel will run 'python scripts/bundle.py --no-chartjs' automatically"

  if ! vercel whoami &>/dev/null 2>&1; then
    info "Logging in to Vercel..."
    vercel login
  fi

  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")

  if [ "$BRANCH" = "main" ] || [ "$BRANCH" = "master" ]; then
    warn "You're on $BRANCH — deploying to PRODUCTION"
    read -rp "Continue? [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || { info "Aborted."; exit 0; }
    vercel --prod
  else
    info "Deploying preview (branch: $BRANCH)"
    vercel
  fi

  success "Deployed to Vercel!"
}

# ── Netlify ───────────────────────────────────────────────────────────────────
deploy_netlify() {
  header "Deploying to Netlify"
  need netlify "npm install -g netlify-cli"
  cd "$ROOT"

  build_bundle

  if ! netlify status &>/dev/null 2>&1; then
    info "Logging in to Netlify..."
    netlify login
  fi

  # Check if site is already linked
  if [ ! -f ".netlify/state.json" ]; then
    info "Initialising Netlify site..."
    netlify init
  fi

  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "main")

  if [ "$BRANCH" = "main" ] || [ "$BRANCH" = "master" ]; then
    warn "Deploying to PRODUCTION"
    read -rp "Continue? [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || { info "Aborted."; exit 0; }
    netlify deploy --prod --dir dist/
  else
    info "Deploying preview..."
    netlify deploy --dir dist/
  fi

  success "Deployed to Netlify!"
}

# ── Render ────────────────────────────────────────────────────────────────────
deploy_render() {
  header "Render deployment"
  cd "$ROOT"

  echo ""
  info "Render reads render.yaml from your repo automatically."
  info "Steps:"
  echo "  1. Push this repo to GitHub:"
  echo "     git add . && git commit -m 'deploy' && git push"
  echo ""
  echo "  2. Go to https://dashboard.render.com → New + → Static Site"
  echo "     Connect GitHub → Select repo → Render reads render.yaml"
  echo ""
  echo "  3. Or trigger a manual deploy if already connected:"
  echo ""

  if command -v curl &>/dev/null; then
    read -rp "  Do you have a Render API key? [y/N] " has_key
    if [[ "$has_key" =~ ^[Yy]$ ]]; then
      read -rp "  Enter RENDER_API_KEY: " RENDER_API_KEY
      read -rp "  Enter SERVICE_ID (from dashboard URL srv-XXXXXX): " SERVICE_ID
      curl -s -X POST "https://api.render.com/v1/services/${SERVICE_ID}/deploys" \
        -H "Authorization: Bearer ${RENDER_API_KEY}" \
        -H "Content-Type: application/json" \
        -d '{}' | python3 -m json.tool 2>/dev/null || true
      success "Deploy triggered on Render!"
    else
      info "No API key — use the Render dashboard or connect via GitHub for auto-deploy."
    fi
  fi
}

# ── Streamlit ─────────────────────────────────────────────────────────────────
deploy_streamlit() {
  header "Streamlit deployment"
  cd "$ROOT"

  build_bundle

  # Ensure dist/index.html is committed
  if git status dist/index.html 2>/dev/null | grep -q "not staged\|Untracked\|modified"; then
    info "Committing dist/index.html to repo (required for Streamlit Cloud)..."
    git add dist/index.html
    git commit -m "chore: rebuild bundle for Streamlit deployment"
  fi

  info "Testing Streamlit app locally..."
  if ! command -v streamlit &>/dev/null; then
    warn "Streamlit not installed. Installing..."
    pip install streamlit --quiet
  fi

  echo ""
  success "Bundle committed. Now:"
  echo ""
  echo "  1. Push to GitHub:"
  echo "     git push"
  echo ""
  echo "  2. Go to https://share.streamlit.io"
  echo "     → New app → Import from GitHub"
  echo "     → Main file: streamlit_app.py"
  echo ""
  echo "  3. Or run locally right now:"
  echo "     streamlit run streamlit_app.py"
  echo ""

  read -rp "Run locally now? [y/N] " run_local
  if [[ "$run_local" =~ ^[Yy]$ ]]; then
    streamlit run streamlit_app.py
  fi
}

# ── GitHub Pages ──────────────────────────────────────────────────────────────
deploy_pages() {
  header "GitHub Pages (via Actions)"
  cd "$ROOT"

  if [ ! -f ".github/workflows/deploy.yml" ]; then
    error ".github/workflows/deploy.yml not found"
  fi

  build_bundle
  git add .
  git status

  read -rp "Commit and push to trigger GitHub Pages deploy? [y/N] " confirm
  [[ "$confirm" =~ ^[Yy]$ ]] || { info "Aborted."; exit 0; }

  read -rp "Commit message [deploy: rebuild bundle]: " MSG
  MSG="${MSG:-deploy: rebuild bundle}"

  git commit -m "$MSG" || true
  git push

  success "Pushed! GitHub Actions will deploy to Pages."
  info "Check status: $(git remote get-url origin 2>/dev/null | sed 's/\.git$//')/actions"
}

# ── Menu ──────────────────────────────────────────────────────────────────────
show_menu() {
  echo ""
  echo -e "${BOLD}🔓 DebtFree Planner — Deployment${RESET}"
  echo "────────────────────────────────"
  echo "  1) Build bundle only"
  echo "  2) Serve locally (http://localhost:3000)"
  echo "  3) Deploy → Vercel"
  echo "  4) Deploy → Netlify"
  echo "  5) Deploy → Render"
  echo "  6) Deploy → Streamlit"
  echo "  7) Deploy → GitHub Pages"
  echo "  q) Quit"
  echo ""
  read -rp "Choose: " choice
  case "$choice" in
    1|build)      build_bundle ;;
    2|local)      deploy_local ;;
    3|vercel)     deploy_vercel ;;
    4|netlify)    deploy_netlify ;;
    5|render)     deploy_render ;;
    6|streamlit)  deploy_streamlit ;;
    7|pages)      deploy_pages ;;
    q|quit|exit)  echo "Bye!"; exit 0 ;;
    *)            warn "Invalid choice"; show_menu ;;
  esac
}

# ── Entry point ───────────────────────────────────────────────────────────────
TARGET="${1:-menu}"
case "$TARGET" in
  build)      build_bundle ;;
  local)      deploy_local ;;
  vercel)     deploy_vercel ;;
  netlify)    deploy_netlify ;;
  render)     deploy_render ;;
  streamlit)  deploy_streamlit ;;
  pages)      deploy_pages ;;
  menu|"")    show_menu ;;
  *)
    echo "Usage: $0 [build|local|vercel|netlify|render|streamlit|pages]"
    exit 1
    ;;
esac
