// wizard.js — 3-step onboarding wizard (Income → Expenses → Debts)

import { state } from '../state.js';
import { formatCurrency, getCurrencies } from '../utils/format.js';
import { calculateMonthlyIncome, analyzeExpenses, calculateSurplus, EXPENSE_CATEGORIES } from '../engine/budgetEngine.js';

const DEBT_TYPES = [
  { value: 'credit_card', label: 'Credit Card' },
  { value: 'personal_loan', label: 'Personal Loan' },
  { value: 'vehicle', label: 'Vehicle Finance' },
  { value: 'home_loan', label: 'Home Loan / Bond' },
  { value: 'student', label: 'Student Loan' },
  { value: 'store_account', label: 'Store Account' },
  { value: 'tax', label: 'Tax / SARS Debt' },
  { value: 'family', label: 'Family / Friend Loan' },
  { value: 'other', label: 'Other' },
];

const EXPENSE_DEFAULTS = [
  { category: 'housing',       name: 'Rent / Bond',             amount: '' },
  { category: 'housing',       name: 'Water & Electricity',     amount: '' },
  { category: 'transport',     name: 'Vehicle Payment',         amount: '' },
  { category: 'transport',     name: 'Fuel',                    amount: '' },
  { category: 'transport',     name: 'Vehicle Insurance',       amount: '' },
  { category: 'food',          name: 'Groceries',               amount: '' },
  { category: 'food',          name: 'Takeaways / Restaurants', amount: '' },
  { category: 'utilities',     name: 'Internet',                amount: '' },
  { category: 'utilities',     name: 'Cell Phone',              amount: '' },
  { category: 'insurance',     name: 'Life / Medical Aid',      amount: '' },
  { category: 'subscriptions', name: 'Streaming / Gym / Other', amount: '' },
  { category: 'entertainment', name: 'Entertainment / Social',  amount: '' },
  { category: 'personal',      name: 'Personal Care',           amount: '' },
];

export function renderWizard(container, onComplete) {
  let currentStep = 1;

  // ── Seed defaults into state if empty ──────────────────────────
  if (state.get('incomeSources').length === 0) {
    state.addIncomeSource('Primary salary / wages', 0);
  }
  if (state.get('expenses').length === 0) {
    EXPENSE_DEFAULTS.forEach(e => state.addExpense(e.category, e.name, 0));
  }

  function render() {
    const s = state.getAll();
    container.innerHTML = `
      <div class="wizard">
        <div class="wizard-progress">
          ${[1,2,3].map(n => `
            <div class="wizard-step-dot ${n < currentStep ? 'done' : n === currentStep ? 'active' : ''}">
              ${n < currentStep ? '✓' : n}
            </div>
            ${n < 3 ? `<div class="wizard-step-line ${n < currentStep ? 'done' : ''}"></div>` : ''}
          `).join('')}
        </div>
        <div class="wizard-labels">
          <span class="${currentStep === 1 ? 'active' : ''}">Income</span>
          <span class="${currentStep === 2 ? 'active' : ''}">Expenses</span>
          <span class="${currentStep === 3 ? 'active' : ''}">Debts</span>
        </div>

        <div class="wizard-body">
          ${currentStep === 1 ? renderStep1(s) : ''}
          ${currentStep === 2 ? renderStep2(s) : ''}
          ${currentStep === 3 ? renderStep3(s) : ''}
        </div>

        <div class="wizard-nav">
          ${currentStep > 1
            ? `<button class="btn btn-ghost" id="btn-back">← Back</button>`
            : `<div></div>`
          }
          ${currentStep < 3
            ? `<button class="btn btn-primary" id="btn-next">Next →</button>`
            : `<button class="btn btn-success btn-lg" id="btn-calc">Calculate My Freedom Plan →</button>`
          }
        </div>
      </div>
    `;

    attachListeners(s);
  }

  // ── Step 1: Income ─────────────────────────────────────────────
  function renderStep1(s) {
    const curr = s.currency;
    const income = calculateMonthlyIncome(s.incomeSources);
    const fc = (n) => formatCurrency(n, curr);

    return `
      <div class="step step-income">
        <div class="step-header">
          <h2>What comes in every month?</h2>
          <p class="step-sub">Enter your <strong>net take-home</strong> income after all tax and deductions.</p>
        </div>

        <div class="field-group">
          <label class="field-label">Currency</label>
          <select class="input-select" id="currency-select">
            ${Object.entries(getCurrencies()).map(([code, c]) =>
              `<option value="${code}" ${curr === code ? 'selected' : ''}>${c.symbol} ${code}</option>`
            ).join('')}
          </select>
        </div>

        <div id="income-sources">
          ${s.incomeSources.map(src => renderIncomeSource(src, curr)).join('')}
        </div>

        <button class="btn btn-ghost btn-sm mt-8" id="add-income">+ Add income source</button>

        <div class="step-total ${income > 0 ? 'visible' : ''}">
          <span>Monthly net income:</span>
          <span class="total-amount">${fc(income)}</span>
        </div>
      </div>
    `;
  }

  function renderIncomeSource(src, curr) {
    return `
      <div class="income-row" data-id="${src.id}">
        <div class="income-main">
          <input class="input-text income-label" type="text" placeholder="Label (e.g. Salary)"
            value="${src.label || ''}" data-id="${src.id}" data-field="label">
          <div class="income-amount-wrap">
            <span class="currency-prefix">${getCurrencies()[curr]?.symbol || 'R'}</span>
            <input class="input-number income-amount" type="number" min="0" step="100"
              placeholder="0.00" value="${src.amount || ''}"
              data-id="${src.id}" data-field="amount">
          </div>
          ${src.id !== state.get('incomeSources')[0]?.id
            ? `<button class="btn-remove" data-remove-income="${src.id}">×</button>`
            : ''}
        </div>
        <label class="toggle-label mt-4">
          <input type="checkbox" class="income-irregular" data-id="${src.id}"
            ${src.isIrregular ? 'checked' : ''}>
          <span>Irregular income (use 3-month average)</span>
        </label>
        ${src.isIrregular ? `
          <div class="irregular-months">
            <span class="field-label-sm">Last 3 months:</span>
            ${[0,1,2].map(i => `
              <div class="income-amount-wrap">
                <span class="currency-prefix">${getCurrencies()[curr]?.symbol || 'R'}</span>
                <input class="input-number irregular-month" type="number" min="0" step="100"
                  placeholder="Month ${i+1}" value="${src.months?.[i] || ''}"
                  data-id="${src.id}" data-mi="${i}">
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
  }

  // ── Step 2: Expenses ───────────────────────────────────────────
  function renderStep2(s) {
    const curr = s.currency;
    const fc = (n) => formatCurrency(n, curr);
    const income = calculateMonthlyIncome(s.incomeSources);
    const { totals } = analyzeExpenses(s.expenses);
    const surplus = income - totals.total;
    const surplusClass = surplus >= 0 ? 'positive' : 'negative';

    // Group expenses by category
    const grouped = {};
    s.expenses.forEach(exp => {
      if (!grouped[exp.category]) grouped[exp.category] = [];
      grouped[exp.category].push(exp);
    });

    const catOrder = ['housing','transport','food','utilities','insurance','subscriptions','childcare','medical','clothing','entertainment','personal','savings','other'];

    return `
      <div class="step step-expenses">
        <div class="step-header">
          <h2>Where does your money go?</h2>
          <p class="step-sub">Enter your actual monthly spend. Leave at <strong>0</strong> for categories that don't apply. This is <em>not</em> a budget — it's a reality check.</p>
        </div>

        <div class="expense-grid">
          ${catOrder.map(cat => {
            const items = grouped[cat] || [];
            const meta = EXPENSE_CATEGORIES[cat];
            if (!meta) return '';
            const catTotal = items.reduce((s, e) => s + Number(e.amount || 0), 0);
            return `
              <div class="expense-category" data-cat="${cat}">
                <div class="cat-header">
                  <span class="cat-icon">${meta.icon}</span>
                  <span class="cat-name">${meta.label}</span>
                  ${catTotal > 0 ? `<span class="cat-total">${fc(catTotal)}</span>` : ''}
                </div>
                ${items.map(exp => renderExpenseRow(exp, curr)).join('')}
                <button class="btn-add-expense" data-add-cat="${cat}">+ Add ${meta.label} item</button>
              </div>
            `;
          }).join('')}
        </div>

        <div class="expense-summary">
          <div class="summary-row">
            <span>Monthly income</span>
            <span>${fc(income)}</span>
          </div>
          <div class="summary-row">
            <span>Total expenses</span>
            <span class="negative">${fc(totals.total)}</span>
          </div>
          <div class="summary-divider"></div>
          <div class="summary-row summary-total">
            <span>Surplus (before debt payments)</span>
            <span class="${surplusClass}">${fc(surplus)}</span>
          </div>
          ${surplus < 0 ? `
            <div class="insight-box warning">
              ⚠️ Your expenses exceed income by ${fc(Math.abs(surplus))}. Review which categories can be reduced before proceeding.
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  function renderExpenseRow(exp, curr) {
    const sym = getCurrencies()[curr]?.symbol || 'R';
    return `
      <div class="expense-row" data-id="${exp.id}">
        <input class="input-text expense-name" type="text"
          placeholder="Description" value="${exp.name || ''}"
          data-id="${exp.id}" data-field="name">
        <div class="income-amount-wrap">
          <span class="currency-prefix">${sym}</span>
          <input class="input-number expense-amount" type="number" min="0" step="10"
            placeholder="0" value="${exp.amount || ''}"
            data-id="${exp.id}" data-field="amount">
        </div>
        <button class="btn-remove" data-remove-expense="${exp.id}">×</button>
      </div>
    `;
  }

  // ── Step 3: Debts ──────────────────────────────────────────────
  function renderStep3(s) {
    const curr = s.currency;
    const fc = (n) => formatCurrency(n, curr);
    const income = calculateMonthlyIncome(s.incomeSources);
    const surplus = calculateSurplus(income, s.expenses, s.debts);

    const totalDebt = s.debts.reduce((t, d) => t + Number(d.balance || 0), 0);
    const totalMin = s.debts.reduce((t, d) => t + Number(d.minPayment || 0), 0);

    return `
      <div class="step step-debts">
        <div class="step-header">
          <h2>List every debt</h2>
          <p class="step-sub">Include credit cards, loans, vehicle finance, store accounts — <strong>every one</strong>. The interest rate (APR) matters most.</p>
        </div>

        ${s.debts.length === 0 ? `
          <div class="empty-state">
            <span class="empty-icon">🎉</span>
            <p>No debts listed yet. Add your first one below, or <button class="btn-link" id="btn-no-debt">skip — I have no debt</button>.</p>
          </div>
        ` : `
          <div class="debt-list" id="debt-list">
            ${s.debts.map(debt => renderDebtRow(debt, curr)).join('')}
          </div>
        `}

        <button class="btn btn-ghost btn-sm mt-8" id="add-debt">+ Add debt</button>

        ${s.debts.length > 0 ? `
          <div class="debt-summary">
            <div class="summary-row">
              <span>Total debt</span>
              <span class="negative">${fc(totalDebt)}</span>
            </div>
            <div class="summary-row">
              <span>Total minimum payments</span>
              <span class="negative">${fc(totalMin)}</span>
            </div>
            <div class="summary-divider"></div>
            <div class="summary-row summary-total">
              <span>Available to attack debt (extra)</span>
              <span class="${surplus.surplusAfterMinimums >= 0 ? 'positive' : 'negative'}">
                ${fc(surplus.surplusAfterMinimums)}
              </span>
            </div>
            ${surplus.cannotCoverMinimums ? `
              <div class="insight-box critical">
                🚨 Minimum payments exceed your available surplus. Your plan needs expense reduction before debt attack is possible.
              </div>
            ` : surplus.surplusAfterMinimums < surplus.income * 0.05 ? `
              <div class="insight-box warning">
                ⚠️ Very slim attack budget. Even small expense reductions will meaningfully accelerate your timeline.
              </div>
            ` : `
              <div class="insight-box success">
                ✅ You have ${fc(surplus.surplusAfterMinimums)}/mo to accelerate debt payoff. That's your weapon.
              </div>
            `}
          </div>
        ` : ''}
      </div>
    `;
  }

  function renderDebtRow(debt, curr) {
    const sym = getCurrencies()[curr]?.symbol || 'R';
    return `
      <div class="debt-card" data-id="${debt.id}">
        <div class="debt-card-header">
          <select class="input-select debt-type" data-id="${debt.id}" data-field="type">
            ${DEBT_TYPES.map(t => `<option value="${t.value}" ${debt.type === t.value ? 'selected' : ''}>${t.label}</option>`).join('')}
          </select>
          <button class="btn-remove" data-remove-debt="${debt.id}">× Remove</button>
        </div>
        <div class="debt-card-body">
          <div class="field-group">
            <label class="field-label-sm">Name / Account</label>
            <input class="input-text debt-name" type="text" placeholder="e.g. FNB Credit Card"
              value="${debt.name || ''}" data-id="${debt.id}" data-field="name">
          </div>
          <div class="debt-fields-row">
            <div class="field-group">
              <label class="field-label-sm">Outstanding balance</label>
              <div class="income-amount-wrap">
                <span class="currency-prefix">${sym}</span>
                <input class="input-number" type="number" min="0" step="100"
                  placeholder="0" value="${debt.balance || ''}"
                  data-id="${debt.id}" data-field="balance">
              </div>
            </div>
            <div class="field-group">
              <label class="field-label-sm">Interest rate (APR %)</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" min="0" max="100" step="0.1"
                  placeholder="e.g. 21.5" value="${debt.apr || ''}"
                  data-id="${debt.id}" data-field="apr">
                <span class="currency-prefix">%</span>
              </div>
            </div>
            <div class="field-group">
              <label class="field-label-sm">Min. monthly payment</label>
              <div class="income-amount-wrap">
                <span class="currency-prefix">${sym}</span>
                <input class="input-number" type="number" min="0" step="10"
                  placeholder="0" value="${debt.minPayment || ''}"
                  data-id="${debt.id}" data-field="minPayment">
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Event listeners ────────────────────────────────────────────
  function attachListeners(s) {
    const curr = s.currency;

    // Currency select
    const currSel = container.querySelector('#currency-select');
    if (currSel) {
      currSel.addEventListener('change', e => {
        state.set('currency', e.target.value);
        render();
      });
    }

    // Nav buttons
    container.querySelector('#btn-next')?.addEventListener('click', () => {
      currentStep++;
      render();
      container.scrollIntoView({ behavior: 'smooth' });
    });

    container.querySelector('#btn-back')?.addEventListener('click', () => {
      currentStep--;
      render();
      container.scrollIntoView({ behavior: 'smooth' });
    });

    container.querySelector('#btn-calc')?.addEventListener('click', () => {
      if (state.get('debts').length === 0 && !confirm('No debts added. Generate a savings-only plan?')) return;
      if (!state.get('planCreatedAt')) state.set('planCreatedAt', new Date().toISOString());
      onComplete();
    });

    container.querySelector('#btn-no-debt')?.addEventListener('click', () => {
      onComplete();
    });

    // Add income
    container.querySelector('#add-income')?.addEventListener('click', () => {
      state.addIncomeSource('Side income', 0);
      render();
    });

    // Income field changes
    container.querySelectorAll('.income-label, .income-amount').forEach(el => {
      el.addEventListener('input', e => {
        const { id, field } = e.target.dataset;
        const val = field === 'amount' ? Number(e.target.value) : e.target.value;
        state.updateIncomeSource(id, { [field]: val });
        // Live-update total without full re-render
        const income = calculateMonthlyIncome(state.get('incomeSources'));
        const totalEl = container.querySelector('.total-amount');
        if (totalEl) totalEl.textContent = formatCurrency(income, state.get('currency'));
        container.querySelector('.step-total')?.classList.toggle('visible', income > 0);
      });
    });

    // Irregular income toggle
    container.querySelectorAll('.income-irregular').forEach(el => {
      el.addEventListener('change', e => {
        state.updateIncomeSource(e.target.dataset.id, { isIrregular: e.target.checked });
        render();
      });
    });

    // Irregular month inputs
    container.querySelectorAll('.irregular-month').forEach(el => {
      el.addEventListener('input', e => {
        const { id, mi } = e.target.dataset;
        const src = state.get('incomeSources').find(s => s.id === id);
        if (!src) return;
        const months = [...(src.months || [0, 0, 0])];
        months[Number(mi)] = Number(e.target.value);
        state.updateIncomeSource(id, { months });
      });
    });

    // Remove income source
    container.querySelectorAll('[data-remove-income]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.removeIncomeSource(e.target.dataset.removeIncome);
        render();
      });
    });

    // Expense field changes
    container.querySelectorAll('.expense-name, .expense-amount').forEach(el => {
      el.addEventListener('input', e => {
        const { id, field } = e.target.dataset;
        const val = field === 'amount' ? Number(e.target.value) : e.target.value;
        state.updateExpense(id, { [field]: val });
        // Lightweight re-render just of totals
        const income = calculateMonthlyIncome(state.get('incomeSources'));
        const { totals } = analyzeExpenses(state.get('expenses'));
        const surplus = income - totals.total;
        const fc = n => formatCurrency(n, state.get('currency'));
        const rows = container.querySelectorAll('.summary-row span:last-child');
        if (rows.length >= 3) {
          rows[1].textContent = fc(totals.total);
          rows[1].className = 'negative';
          rows[2].textContent = fc(surplus);
          rows[2].className = surplus >= 0 ? 'positive' : 'negative';
        }
        // Update cat total
        const catEl = e.target.closest('[data-cat]');
        if (catEl) {
          const cat = catEl.dataset.cat;
          const catItems = state.get('expenses').filter(e => e.category === cat);
          const catTotal = catItems.reduce((s, e) => s + Number(e.amount || 0), 0);
          const ctEl = catEl.querySelector('.cat-total');
          if (catTotal > 0) {
            if (ctEl) ctEl.textContent = fc(catTotal);
            else {
              const h = catEl.querySelector('.cat-header');
              if (h) h.insertAdjacentHTML('beforeend', `<span class="cat-total">${fc(catTotal)}</span>`);
            }
          } else if (ctEl) ctEl.textContent = '';
        }
      });
    });

    // Add expense by category
    container.querySelectorAll('[data-add-cat]').forEach(btn => {
      btn.addEventListener('click', e => {
        const cat = e.target.dataset.addCat;
        state.addExpense(cat, '', 0);
        render();
      });
    });

    // Remove expense
    container.querySelectorAll('[data-remove-expense]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.removeExpense(e.target.dataset.removeExpense);
        render();
      });
    });

    // Add debt
    container.querySelector('#add-debt')?.addEventListener('click', () => {
      state.addDebt('', 'credit_card', 0, 0, 0);
      render();
    });

    // Debt field changes
    container.querySelectorAll('.debt-name, .debt-type').forEach(el => {
      el.addEventListener('change', e => {
        state.updateDebt(e.target.dataset.id, { [e.target.dataset.field]: e.target.value });
      });
    });

    container.querySelectorAll('.debt-card input[type="number"]').forEach(el => {
      el.addEventListener('input', e => {
        const { id, field } = e.target.dataset;
        if (!id || !field) return;
        state.updateDebt(id, { [field]: Number(e.target.value) });
        // Refresh summary
        const income = calculateMonthlyIncome(state.get('incomeSources'));
        const surplus = calculateSurplus(income, state.get('expenses'), state.get('debts'));
        const fc = n => formatCurrency(n, state.get('currency'));
        const sumRows = container.querySelectorAll('.debt-summary .summary-row span:last-child');
        const totalDebt = state.get('debts').reduce((t, d) => t + Number(d.balance || 0), 0);
        const totalMin = state.get('debts').reduce((t, d) => t + Number(d.minPayment || 0), 0);
        if (sumRows[0]) sumRows[0].textContent = fc(totalDebt);
        if (sumRows[1]) sumRows[1].textContent = fc(totalMin);
        if (sumRows[2]) {
          sumRows[2].textContent = fc(surplus.surplusAfterMinimums);
          sumRows[2].className = surplus.surplusAfterMinimums >= 0 ? 'positive' : 'negative';
        }
      });
    });

    // Remove debt
    container.querySelectorAll('[data-remove-debt]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.removeDebt(e.target.dataset.removeDebt);
        render();
      });
    });
  }

  render();
}
