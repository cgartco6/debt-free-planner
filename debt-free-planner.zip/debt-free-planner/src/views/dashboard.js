// dashboard.js — Main dashboard: Liberation Timeline, Phase Roadmap, Schedule, Projections

import { state } from '../state.js';
import { formatCurrency, formatCurrencyCompact, formatMonths, monthYearFromOffset } from '../utils/format.js';
import { calculateMonthlyIncome, analyzeExpenses, calculateSurplus, calcFreedomScore, generateBudgetInsights, EXPENSE_CATEGORIES } from '../engine/budgetEngine.js';
import { calculateSchedule, compareStrategies, minimumsOnlySchedule, getTotalDebtSeries, STRATEGIES } from '../engine/debtEngine.js';
import { generatePhases, PHASE_META } from '../engine/phaseEngine.js';
import { generateWealthTimeline } from '../engine/savingsEngine.js';

export function renderDashboard(container, onEditPlan) {
  let activeTab = 'overview';
  let activePhaseId = null;
  let showFullSchedule = false;

  function compute() {
    const s = state.getAll();
    const currency = s.currency;
    const fc = n => formatCurrency(n, currency);
    const fcc = n => formatCurrencyCompact(n, currency);

    const income = calculateMonthlyIncome(s.incomeSources);
    const { totals } = analyzeExpenses(s.expenses);
    const surplus = calculateSurplus(income, s.expenses, s.debts);
    const freedomScore = calcFreedomScore(income, s.expenses, s.debts, s.efBalance);
    const insights = generateBudgetInsights(income, s.expenses, s.debts);

    const schedule = calculateSchedule(
      s.debts,
      Math.max(0, surplus.surplusAfterMinimums),
      s.strategy,
      s.snowflakes
    );

    const comparison = s.debts.length > 0 ? compareStrategies(s.debts, Math.max(0, surplus.surplusAfterMinimums)) : null;
    const minimumsOnly = s.debts.length > 0 ? minimumsOnlySchedule(s.debts) : null;

    const phases = generatePhases(
      { income, totalExpenses: totals.total, totalMinimums: surplus.totalMinimums, surplusAfterMinimums: surplus.surplusAfterMinimums },
      schedule,
      s.debts,
      { currency, efMonthlyPct: s.efMonthlyPct, investSplit: s.investSplit }
    );

    const totalDebt = s.debts.reduce((t, d) => t + Number(d.balance), 0);
    const totalFreedPayments = surplus.totalMinimums + Math.max(0, surplus.surplusAfterMinimums);
    const wealthTimeline = generateWealthTimeline(
      totalFreedPayments,
      { investPct: s.investSplit, savingsPct: 1 - s.investSplit },
      { investReturn: s.investReturnPct, savingsReturn: s.savingsReturnPct },
      s.projectionYears
    );

    const interestSavedVsMinimums = minimumsOnly
      ? minimumsOnly.totalInterest - schedule.totalInterest
      : 0;

    // Determine active phase (0 if fresh, 2 if >1 month, etc.)
    if (activePhaseId === null) activePhaseId = phases[0]?.id ?? 0;

    return {
      s, currency, fc, fcc, income, totals, surplus, freedomScore, insights,
      schedule, comparison, minimumsOnly, phases, totalDebt, wealthTimeline,
      interestSavedVsMinimums, totalFreedPayments
    };
  }

  function render() {
    const data = compute();
    const { s, currency, fc, fcc, income, totals, surplus, freedomScore, insights,
      schedule, comparison, phases, totalDebt, wealthTimeline, interestSavedVsMinimums } = data;

    container.innerHTML = `
      <div class="dashboard">

        <!-- SIDEBAR -->
        <aside class="sidebar">
          <div class="sidebar-brand">
            <span class="brand-icon">🔓</span>
            <span class="brand-name">Debt<strong>Free</strong></span>
          </div>

          <div class="freedom-score-wrap">
            <div class="freedom-score" title="Financial Freedom Score (0–100)">
              <svg class="score-ring" viewBox="0 0 80 80">
                <circle class="ring-bg" cx="40" cy="40" r="34"/>
                <circle class="ring-fill" cx="40" cy="40" r="34"
                  stroke-dasharray="${freedomScore * 2.136} 213.6"
                  stroke-dashoffset="0"
                  style="stroke:${scoreColor(freedomScore)}"/>
                <text x="40" y="44" class="score-text">${freedomScore}</text>
              </svg>
              <div class="score-label">Freedom Score</div>
            </div>
          </div>

          <div class="sidebar-stats">
            <div class="sidebar-stat">
              <span class="stat-label">Debt-Free</span>
              <span class="stat-value">${schedule.totalMonths > 0 ? monthYearFromOffset(schedule.totalMonths) : 'No debts!'}</span>
            </div>
            <div class="sidebar-stat">
              <span class="stat-label">Timeline</span>
              <span class="stat-value">${formatMonths(schedule.totalMonths)}</span>
            </div>
            <div class="sidebar-stat">
              <span class="stat-label">Total Debt</span>
              <span class="stat-value negative">${fcc(totalDebt)}</span>
            </div>
            <div class="sidebar-stat">
              <span class="stat-label">Attack Budget</span>
              <span class="stat-value ${surplus.surplusAfterMinimums >= 0 ? 'positive' : 'negative'}">${fc(surplus.surplusAfterMinimums)}/mo</span>
            </div>
          </div>

          <nav class="sidebar-nav">
            <button class="nav-item ${activeTab === 'overview' ? 'active' : ''}" data-tab="overview">📊 Overview</button>
            <button class="nav-item ${activeTab === 'schedule' ? 'active' : ''}" data-tab="schedule">📅 Month-by-Month</button>
            <button class="nav-item ${activeTab === 'projection' ? 'active' : ''}" data-tab="projection">🚀 Wealth Projection</button>
            <button class="nav-item ${activeTab === 'compare' ? 'active' : ''}" data-tab="compare">⚖️ Compare Strategies</button>
            <button class="nav-item ${activeTab === 'settings' ? 'active' : ''}" data-tab="settings">⚙️ Settings</button>
          </nav>

          <div class="sidebar-actions">
            <button class="btn btn-ghost btn-sm" id="btn-edit-plan">✏️ Edit Plan</button>
            <button class="btn btn-ghost btn-sm btn-danger" id="btn-reset">🗑 Reset</button>
          </div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">

          ${activeTab === 'overview' ? renderOverviewTab(data) : ''}
          ${activeTab === 'schedule' ? renderScheduleTab(data) : ''}
          ${activeTab === 'projection' ? renderProjectionTab(data) : ''}
          ${activeTab === 'compare' ? renderCompareTab(data) : ''}
          ${activeTab === 'settings' ? renderSettingsTab(data) : ''}

        </main>
      </div>
    `;

    attachListeners(data);
    if (activeTab === 'projection' && wealthTimeline.timeline.length > 0) {
      renderWealthChart(data);
    }
    if (activeTab === 'schedule' && schedule.schedule.length > 0) {
      renderDebtChart(data);
    }
  }

  // ── OVERVIEW TAB ─────────────────────────────────────────────────────────
  function renderOverviewTab(data) {
    const { s, fc, fcc, income, totals, surplus, schedule, phases,
      interestSavedVsMinimums, insights, wealthTimeline, totalDebt } = data;

    const currentPhase = phases.find(p => p.id === activePhaseId) || phases[0];

    return `
      <!-- Liberation Timeline -->
      <section class="liberation-timeline-section">
        <h2 class="section-title">Your Liberation Timeline</h2>
        ${renderLiberationTimeline(schedule, s.strategy, data)}
      </section>

      <!-- Key Metrics -->
      <section class="metrics-grid">
        ${[
          { label: 'Monthly Income', value: fc(income), icon: '💰', cls: '' },
          { label: 'Monthly Expenses', value: fc(totals.total), icon: '📤', cls: 'negative' },
          { label: 'Attack Budget', value: `${fc(surplus.surplusAfterMinimums)}/mo`, icon: '⚔️', cls: surplus.surplusAfterMinimums >= 0 ? 'positive' : 'negative' },
          { label: 'Interest Saved', value: fc(interestSavedVsMinimums), icon: '💸', cls: 'positive' },
        ].map(m => `
          <div class="metric-card">
            <span class="metric-icon">${m.icon}</span>
            <span class="metric-label">${m.label}</span>
            <span class="metric-value ${m.cls}">${m.value}</span>
          </div>
        `).join('')}
      </section>

      <!-- Budget Insights -->
      ${insights.length > 0 ? `
        <section class="insights-section">
          ${insights.map(ins => `
            <div class="insight-card insight-${ins.type}">
              <span class="insight-icon">${{success:'✅',info:'💡',warning:'⚠️',critical:'🚨'}[ins.type]}</span>
              <div>
                <strong>${ins.title}</strong>
                <p>${ins.message}</p>
              </div>
            </div>
          `).join('')}
        </section>
      ` : ''}

      <!-- Phase Roadmap -->
      <section class="phases-section">
        <h2 class="section-title">Your 5-Phase Freedom Roadmap</h2>
        <div class="phase-tabs">
          ${phases.map(p => `
            <button class="phase-tab ${p.id === activePhaseId ? 'active' : ''}" data-phase="${p.id}">
              <span>${p.emoji}</span>
              <span class="phase-tab-name">Phase ${p.id}</span>
            </button>
          `).join('')}
        </div>

        ${currentPhase ? renderPhaseDetail(currentPhase, fc) : ''}
      </section>

      <!-- Debt Payoff Cascade -->
      ${schedule.payoffSequence?.length > 0 ? `
        <section class="cascade-section">
          <h2 class="section-title">The Payoff Cascade</h2>
          <p class="section-sub">Each debt that falls adds its payment to the attack on the next. Your attack budget grows automatically.</p>
          <div class="cascade">
            ${renderCascade(schedule.payoffSequence, phases[2]?.payoffCascade || [], fc, s.strategy)}
          </div>
        </section>
      ` : ''}

      <!-- Post-Debt Teaser -->
      ${wealthTimeline.at10Years ? `
        <section class="wealth-teaser">
          <div class="teaser-content">
            <h3>After ${monthYearFromOffset(schedule.totalMonths)} — your money works for you</h3>
            <div class="teaser-stats">
              <div class="teaser-stat">
                <span class="teaser-value">${fc(data.totalFreedPayments)}/mo</span>
                <span class="teaser-label">Former debt payments → now yours</span>
              </div>
              <div class="teaser-stat">
                <span class="teaser-value">${fcc(wealthTimeline.at10Years.total)}</span>
                <span class="teaser-label">Projected at 10 years</span>
              </div>
              ${wealthTimeline.at20Years ? `
                <div class="teaser-stat">
                  <span class="teaser-value">${fcc(wealthTimeline.at20Years.total)}</span>
                  <span class="teaser-label">Projected at 20 years</span>
                </div>
              ` : ''}
            </div>
            <button class="btn btn-outline" data-tab="projection">See full projection →</button>
          </div>
        </section>
      ` : ''}
    `;
  }

  function renderLiberationTimeline(schedule, strategy, data) {
    const { phases, fc } = data;
    if (schedule.totalMonths === 0) {
      return `<div class="timeline-empty">Add debts to see your liberation timeline.</div>`;
    }

    // Timeline spans: debt phase (0→totalMonths) + wealth phase (+10 years visual)
    const totalVisualMonths = schedule.totalMonths + 60; // show 5 years of wealth building
    const debtPct = (schedule.totalMonths / totalVisualMonths) * 100;
    const wealthPct = 100 - debtPct;
    const todayPct = 1; // always at the very start

    // Milestone markers
    const milestones = (schedule.milestones || []).map(m => ({
      pct: (m.month / totalVisualMonths) * 100,
      label: m.debtName,
      type: 'payoff',
    }));

    const stratLabel = STRATEGIES[strategy]?.label || strategy;

    return `
      <div class="liberation-timeline">
        <div class="timeline-bar-wrap">
          <div class="timeline-bar">
            <div class="timeline-debt-phase" style="width:${debtPct}%">
              <span class="timeline-phase-label">⚔️ ${stratLabel} Attack — ${formatMonths(schedule.totalMonths)}</span>
            </div>
            <div class="timeline-wealth-phase" style="width:${wealthPct}%">
              <span class="timeline-phase-label">🚀 Wealth Building</span>
            </div>
            <!-- Today marker -->
            <div class="timeline-marker timeline-today" style="left:${todayPct}%">
              <div class="marker-pin"></div>
              <div class="marker-label marker-label-top">TODAY</div>
            </div>
            <!-- Debt-free marker -->
            <div class="timeline-marker timeline-debt-free" style="left:${debtPct}%">
              <div class="marker-pin"></div>
              <div class="marker-label marker-label-top">DEBT FREE<br>${monthYearFromOffset(schedule.totalMonths)}</div>
            </div>
            <!-- Milestone markers -->
            ${milestones.map(m => `
              <div class="timeline-milestone" style="left:${m.pct}%" title="${m.label} paid off">
                <div class="milestone-dot"></div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="timeline-legend">
          <span>⚔️ Debt Attack Phase</span>
          <span class="legend-sep">|</span>
          ${(schedule.milestones || []).map(m => `<span class="legend-milestone">● ${m.debtName}</span>`).join(' ')}
          <span class="legend-sep">|</span>
          <span>🚀 Freedom & Wealth</span>
        </div>
      </div>
    `;
  }

  function renderPhaseDetail(phase, fc) {
    return `
      <div class="phase-detail phase-detail-${phase.id}">
        <div class="phase-detail-header">
          <div>
            <div class="phase-badge">Phase ${phase.id} · ${phase.name} ${phase.emoji}</div>
            <p class="phase-tagline">${phase.tagline}</p>
            ${phase.duration ? `<p class="phase-duration">Duration: ${formatMonths(phase.duration)}</p>` : ''}
          </div>
          <div class="phase-summary-text">${phase.summary}</div>
        </div>

        <div class="phase-actions">
          <h4>Actions for this phase:</h4>
          <ul class="action-list">
            ${(phase.actions || []).map(action => `
              <li class="action-item ${state.isActionDone(action.id) ? 'done' : ''}">
                <button class="action-check ${state.isActionDone(action.id) ? 'checked' : ''}"
                  data-action="${action.id}">
                  ${state.isActionDone(action.id) ? '✓' : '○'}
                </button>
                <span class="action-text">${action.text}</span>
              </li>
            `).join('')}
          </ul>
        </div>

        ${phase.milestones?.length > 0 ? `
          <div class="phase-milestones">
            <h4>Milestones:</h4>
            ${phase.milestones.map(m => `
              <div class="milestone-item">
                <span class="milestone-dot-sm">◆</span>
                <span>${m.label}</span>
                ${m.month ? `<span class="milestone-date">${monthYearFromOffset(m.month)}</span>` : ''}
                ${m.freedPayment ? `<span class="milestone-freed">(frees ${fc(m.freedPayment)}/mo)</span>` : ''}
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
  }

  function renderCascade(payoffSequence, cascade, fc, strategy) {
    const stratLabel = STRATEGIES[strategy]?.label || strategy;

    return payoffSequence.map((p, i) => {
      const cItem = cascade[i] || {};
      return `
        <div class="cascade-item">
          <div class="cascade-order">${i + 1}</div>
          <div class="cascade-content">
            <div class="cascade-debt-name">${p.name}</div>
            <div class="cascade-meta">
              <span>Balance: ${fc(p.originalBalance)}</span>
              <span>Interest paid: ${fc(p.totalInterestPaid)}</span>
              <span class="cascade-date">Paid off: ${monthYearFromOffset(p.paidMonth)}</span>
            </div>
          </div>
          <div class="cascade-arrow ${i < payoffSequence.length - 1 ? '' : 'arrow-last'}">
            ${i < payoffSequence.length - 1 ? `
              <div class="cascade-roll">
                ${fc(p.freedPayment)}/mo rolls →
              </div>
              <span>↓</span>
            ` : `
              <div class="cascade-freedom">
                🎉 ${fc(cItem.rollingAfter || p.freedPayment)}/mo → YOURS
              </div>
            `}
          </div>
        </div>
      `;
    }).join('');
  }

  // ── SCHEDULE TAB ─────────────────────────────────────────────────────────
  function renderScheduleTab(data) {
    const { schedule, s, fc } = data;

    if (schedule.schedule.length === 0) {
      return `<div class="empty-tab"><p>No debts to schedule. Add debts in the wizard.</p></div>`;
    }

    const displayMonths = showFullSchedule ? schedule.schedule : schedule.schedule.slice(0, 24);
    const debtNames = s.debts.map(d => d.name);

    return `
      <section class="schedule-section">
        <div class="schedule-header">
          <h2 class="section-title">Month-by-Month Schedule</h2>
          <div class="schedule-controls">
            <span class="strategy-badge">${STRATEGIES[s.strategy]?.label || s.strategy}</span>
            <span class="total-months">${schedule.totalMonths} months to freedom</span>
          </div>
        </div>

        <div class="chart-container">
          <canvas id="debt-chart" height="200"></canvas>
        </div>

        <div class="schedule-table-wrap">
          <table class="schedule-table">
            <thead>
              <tr>
                <th>Month</th>
                <th>Date</th>
                ${debtNames.map(n => `<th>${n}</th>`).join('')}
                <th>Interest</th>
                <th>Principal</th>
                <th>Total Debt</th>
              </tr>
            </thead>
            <tbody>
              ${displayMonths.map(m => {
                const totalBal = m.debts.reduce((s, d) => s + (d.balance || 0), 0);
                const milestone = schedule.milestones.find(ms => ms.month === m.month);
                return `
                  <tr class="${milestone ? 'milestone-row' : m.month % 2 === 0 ? 'even' : ''}">
                    <td class="month-num">${m.month}</td>
                    <td class="month-date">${monthYearFromOffset(m.month)}</td>
                    ${s.debts.map(debt => {
                      const dRow = m.debts.find(d => d.id === debt.id);
                      return dRow
                        ? `<td class="${dRow.isTarget ? 'target-col' : ''} ${dRow.balance <= 0 ? 'paid-col' : ''}">
                            ${dRow.balance <= 0 ? '✓ PAID' : fc(dRow.balance)}
                            ${dRow.isTarget && dRow.balance > 0 ? '<span class="target-marker">▲</span>' : ''}
                          </td>`
                        : `<td class="paid-col">✓ PAID</td>`;
                    }).join('')}
                    <td class="interest-col">${fc(m.totalInterest)}</td>
                    <td>${fc(m.totalPrincipal)}</td>
                    <td class="total-bal">${fc(totalBal)}</td>
                  </tr>
                  ${milestone ? `
                    <tr class="milestone-row-label">
                      <td colspan="${3 + s.debts.length}" class="milestone-cell">
                        🎉 "${milestone.debtName}" PAID OFF — ${fc(milestone.freedPayment)}/mo rolls forward
                      </td>
                    </tr>
                  ` : ''}
                `;
              }).join('')}
            </tbody>
          </table>
        </div>

        ${!showFullSchedule && schedule.schedule.length > 24 ? `
          <div class="show-more">
            <button class="btn btn-ghost" id="btn-show-full">Show all ${schedule.schedule.length} months →</button>
          </div>
        ` : ''}

        <div class="schedule-totals">
          <div class="totals-row">
            <span>Total interest paid:</span>
            <span class="negative">${fc(schedule.totalInterest)}</span>
          </div>
          <div class="totals-row">
            <span>Total principal repaid:</span>
            <span>${fc(schedule.totalPrincipal)}</span>
          </div>
          <div class="totals-row totals-row-highlight">
            <span>Debt-free date:</span>
            <span class="positive">${monthYearFromOffset(schedule.totalMonths)}</span>
          </div>
        </div>

        <!-- Snowflakes -->
        <div class="snowflakes-section">
          <h3>💸 One-off Extra Payments (Snowflakes)</h3>
          <p class="section-sub">A bonus, tax refund, or windfall? Drop it here to see the impact on your timeline.</p>
          <div class="snowflake-form">
            <input class="input-number" type="number" id="sf-month" placeholder="Month #" min="1" max="${schedule.totalMonths}" style="width:100px">
            <input class="input-number" id="sf-amount" type="number" placeholder="Amount" min="0">
            <input class="input-text" id="sf-note" type="text" placeholder="Note (optional)" style="width:150px">
            <button class="btn btn-primary btn-sm" id="add-snowflake">Add →</button>
          </div>
          ${s.snowflakes.length > 0 ? `
            <div class="snowflake-list">
              ${s.snowflakes.map(sf => `
                <div class="snowflake-item">
                  <span>Month ${sf.month}: ${fc(sf.amount)} ${sf.note ? `(${sf.note})` : ''}</span>
                  <button class="btn-remove" data-remove-sf="${sf.id}">×</button>
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>
      </section>
    `;
  }

  // ── PROJECTION TAB ───────────────────────────────────────────────────────
  function renderProjectionTab(data) {
    const { wealthTimeline, fc, fcc, schedule, s, totalFreedPayments } = data;
    const { timeline, milestones, investMonthly, savingsMonthly } = wealthTimeline;

    return `
      <section class="projection-section">
        <div class="projection-header">
          <h2 class="section-title">Your Wealth After ${monthYearFromOffset(schedule.totalMonths)}</h2>
          <p class="section-sub">When your last debt is paid off, <strong>${fc(totalFreedPayments)}/mo</strong> that was going to lenders starts building your future. This is what debt payoff is really about.</p>
        </div>

        <div class="projection-split">
          <div class="split-card">
            <span class="split-icon">📈</span>
            <span class="split-label">Investments (${(s.investSplit * 100).toFixed(0)}%)</span>
            <span class="split-amount">${fc(investMonthly)}/mo</span>
            <span class="split-rate">@ ${s.investReturnPct}% p/a (equities/ETF)</span>
          </div>
          <div class="split-card">
            <span class="split-icon">🏦</span>
            <span class="split-label">Savings (${((1 - s.investSplit) * 100).toFixed(0)}%)</span>
            <span class="split-amount">${fc(savingsMonthly)}/mo</span>
            <span class="split-rate">@ ${s.savingsReturnPct}% p/a (HYSA/bonds)</span>
          </div>
        </div>

        <div class="chart-container">
          <canvas id="wealth-chart" height="250"></canvas>
        </div>

        ${milestones.length > 0 ? `
          <div class="wealth-milestones">
            <h3>Wealth Milestones</h3>
            <div class="milestone-grid">
              ${milestones.map(m => `
                <div class="wealth-milestone">
                  <span class="wm-icon">💎</span>
                  <span class="wm-amount">${fcc(m.amount)}</span>
                  <span class="wm-year">Year ${m.year} after debt freedom</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <div class="projection-table-wrap">
          <table class="projection-table">
            <thead>
              <tr>
                <th>Year</th>
                <th>Contributed</th>
                <th>Growth</th>
                <th>Investments</th>
                <th>Savings</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              ${timeline.map(y => `
                <tr class="${y.year % 5 === 0 ? 'highlight-row' : ''}">
                  <td>${y.year}</td>
                  <td>${fc(y.contributed)}</td>
                  <td class="positive">${fc(y.growth)} (${y.growth > 0 ? '+' : ''}${((y.growth / y.contributed) * 100).toFixed(0)}%)</td>
                  <td>${fc(y.investments)}</td>
                  <td>${fc(y.savings)}</td>
                  <td class="positive total-wealth">${fcc(y.total)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <div class="projection-disclaimer">
          <p>⚠️ Projections assume consistent monthly contributions and stated annual returns. Actual investment returns vary. This is for planning purposes only — not financial advice. Past market performance does not guarantee future results.</p>
        </div>
      </section>
    `;
  }

  // ── COMPARE TAB ──────────────────────────────────────────────────────────
  function renderCompareTab(data) {
    const { comparison, s, fc } = data;
    if (!comparison) {
      return `<div class="empty-tab"><p>Add debts to compare strategies.</p></div>`;
    }

    const current = s.strategy;

    return `
      <section class="compare-section">
        <h2 class="section-title">Strategy Comparison</h2>
        <p class="section-sub">Same budget, same debts, three different approaches. The difference in interest is real money.</p>

        <div class="compare-grid">
          ${Object.entries(comparison).map(([key, result]) => {
            const meta = STRATEGIES[key];
            const isCurrent = key === current;
            const interestDiff = result.totalInterest - comparison.avalanche.totalInterest;
            return `
              <div class="compare-card ${isCurrent ? 'compare-card-active' : ''}">
                ${isCurrent ? '<div class="current-badge">Your current strategy</div>' : ''}
                <h3 class="compare-strategy-name">${meta.label}</h3>
                <p class="compare-tagline">${meta.tagline}</p>
                <p class="compare-desc">${meta.description}</p>
                <div class="compare-stats">
                  <div class="compare-stat">
                    <span class="cs-label">Debt-free in</span>
                    <span class="cs-value">${formatMonths(result.totalMonths)}</span>
                  </div>
                  <div class="compare-stat">
                    <span class="cs-label">Total interest</span>
                    <span class="cs-value negative">${fc(result.totalInterest)}</span>
                  </div>
                  ${key !== 'avalanche' && interestDiff > 0 ? `
                    <div class="compare-stat">
                      <span class="cs-label">Extra interest vs Avalanche</span>
                      <span class="cs-value warning">+${fc(interestDiff)}</span>
                    </div>
                  ` : key === 'avalanche' ? `
                    <div class="compare-stat">
                      <span class="cs-label">Interest saved</span>
                      <span class="cs-value positive">Most optimal</span>
                    </div>
                  ` : ''}
                </div>
                ${!isCurrent ? `
                  <button class="btn btn-outline btn-sm mt-8" data-switch-strategy="${key}">
                    Switch to ${meta.label}
                  </button>
                ` : ''}
              </div>
            `;
          }).join('')}
        </div>

        <div class="compare-note">
          <strong>Recommendation:</strong> If you're disciplined and numbers-driven, <strong>Avalanche</strong> saves the most.
          If you need visible wins to stay motivated, <strong>Snowball</strong> pays off accounts fastest.
          <strong>Hybrid</strong> balances both. The best strategy is the one you stick to — all three beat paying minimums only.
        </div>
      </section>
    `;
  }

  // ── SETTINGS TAB ─────────────────────────────────────────────────────────
  function renderSettingsTab(data) {
    const { s, fc } = data;

    return `
      <section class="settings-section">
        <h2 class="section-title">Plan Settings</h2>

        <div class="settings-grid">
          <div class="settings-group">
            <h3>Payoff Strategy</h3>
            <div class="radio-group">
              ${Object.entries(STRATEGIES).map(([key, meta]) => `
                <label class="radio-option ${s.strategy === key ? 'selected' : ''}">
                  <input type="radio" name="strategy" value="${key}" ${s.strategy === key ? 'checked' : ''}>
                  <div>
                    <strong>${meta.label}</strong>
                    <span>${meta.tagline}</span>
                  </div>
                </label>
              `).join('')}
            </div>
          </div>

          <div class="settings-group">
            <h3>Emergency Fund</h3>
            <div class="field-group">
              <label class="field-label">Current EF balance</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="ef-balance"
                  value="${s.efBalance}" min="0" step="100">
              </div>
            </div>
            <div class="field-group">
              <label class="field-label">% of surplus to EF (Phase 1)</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="ef-pct"
                  value="${(s.efMonthlyPct * 100).toFixed(0)}" min="5" max="50" step="5">
                <span class="currency-prefix">%</span>
              </div>
            </div>
          </div>

          <div class="settings-group">
            <h3>Wealth Building (Phase 4)</h3>
            <div class="field-group">
              <label class="field-label">Investment split</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="invest-split"
                  value="${(s.investSplit * 100).toFixed(0)}" min="0" max="100" step="5">
                <span class="currency-prefix">% investments</span>
              </div>
            </div>
            <div class="field-group">
              <label class="field-label">Investment return (% p/a)</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="invest-return"
                  value="${s.investReturnPct}" min="1" max="20" step="0.5">
                <span class="currency-prefix">%</span>
              </div>
            </div>
            <div class="field-group">
              <label class="field-label">Savings return (% p/a)</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="savings-return"
                  value="${s.savingsReturnPct}" min="1" max="15" step="0.5">
                <span class="currency-prefix">%</span>
              </div>
            </div>
            <div class="field-group">
              <label class="field-label">Projection horizon (years)</label>
              <div class="income-amount-wrap">
                <input class="input-number" type="number" id="proj-years"
                  value="${s.projectionYears}" min="5" max="40" step="5">
              </div>
            </div>
          </div>

          <div class="settings-group">
            <h3>Data</h3>
            <div class="data-buttons">
              <button class="btn btn-ghost btn-sm" id="btn-export">📥 Export JSON</button>
              <label class="btn btn-ghost btn-sm" style="cursor:pointer">
                📤 Import JSON
                <input type="file" id="import-file" accept=".json" style="display:none">
              </label>
            </div>
          </div>
        </div>
      </section>
    `;
  }

  // ── CHARTS ───────────────────────────────────────────────────────────────
  function renderDebtChart(data) {
    const canvas = document.getElementById('debt-chart');
    if (!canvas || !window.Chart) return;
    const { schedule, data: d } = { schedule: data.schedule, data };
    const { s, fc } = data;
    const labels = schedule.schedule.map(m => monthYearFromOffset(m.month));
    const ctx = canvas.getContext('2d');

    const datasets = s.debts.map((debt, i) => {
      const colors = ['#EF4444','#F59E0B','#06B6D4','#8B5CF6','#10B981','#F97316'];
      const balances = schedule.schedule.map(m => {
        const d = m.debts.find(x => x.id === debt.id);
        return d ? d.balance : 0;
      });
      return {
        label: debt.name,
        data: balances,
        borderColor: colors[i % colors.length],
        backgroundColor: colors[i % colors.length] + '20',
        fill: true,
        tension: 0.3,
        pointRadius: 0,
      };
    });

    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(ctx, {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'top', labels: { color: '#475569' } },
          tooltip: {
            callbacks: { label: ctx => `${ctx.dataset.label}: ${fc(ctx.raw)}` },
          },
        },
        scales: {
          x: { ticks: { maxTicksLimit: 12, color: '#94A3B8' }, grid: { color: '#E2E8F020' } },
          y: { ticks: { color: '#94A3B8', callback: v => formatCurrencyCompact(v, s.currency) }, grid: { color: '#E2E8F030' } },
        },
      },
    });
  }

  function renderWealthChart(data) {
    const canvas = document.getElementById('wealth-chart');
    if (!canvas || !window.Chart) return;
    const { wealthTimeline, fc, s } = data;
    const { timeline } = wealthTimeline;
    const ctx = canvas.getContext('2d');
    const labels = timeline.map(y => `Year ${y.year}`);

    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Contributed',
            data: timeline.map(y => y.contributed),
            backgroundColor: '#94A3B8',
            stack: 'wealth',
          },
          {
            label: 'Investment Growth',
            data: timeline.map(y => y.growth),
            backgroundColor: '#10B981',
            stack: 'wealth',
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'top', labels: { color: '#475569' } },
          tooltip: {
            callbacks: { label: ctx => `${ctx.dataset.label}: ${fc(ctx.raw)}` },
          },
        },
        scales: {
          x: { stacked: true, ticks: { color: '#94A3B8' }, grid: { color: '#E2E8F020' } },
          y: { stacked: true, ticks: { color: '#94A3B8', callback: v => formatCurrencyCompact(v, s.currency) }, grid: { color: '#E2E8F030' } },
        },
      },
    });
  }

  // ── EVENT LISTENERS ───────────────────────────────────────────────────────
  function attachListeners(data) {
    const { s } = data;

    // Sidebar nav
    container.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', e => {
        activeTab = e.currentTarget.dataset.tab;
        render();
        container.querySelector('.main-content')?.scrollIntoView({ behavior: 'smooth' });
      });
    });

    // Phase tabs
    container.querySelectorAll('[data-phase]').forEach(btn => {
      btn.addEventListener('click', e => {
        activePhaseId = Number(e.currentTarget.dataset.phase);
        render();
      });
    });

    // Action checkboxes
    container.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.toggleAction(e.currentTarget.dataset.action);
        // Lightweight update of this action item only
        const id = e.currentTarget.dataset.action;
        const item = e.currentTarget.closest('.action-item');
        const isDone = state.isActionDone(id);
        e.currentTarget.textContent = isDone ? '✓' : '○';
        e.currentTarget.classList.toggle('checked', isDone);
        item?.classList.toggle('done', isDone);
      });
    });

    // Edit plan
    container.querySelector('#btn-edit-plan')?.addEventListener('click', onEditPlan);

    // Reset
    container.querySelector('#btn-reset')?.addEventListener('click', () => {
      if (confirm('Reset all data? This cannot be undone.')) {
        state.reset();
        onEditPlan();
      }
    });

    // Show full schedule
    container.querySelector('#btn-show-full')?.addEventListener('click', () => {
      showFullSchedule = true;
      render();
    });

    // Snowflake
    container.querySelector('#add-snowflake')?.addEventListener('click', () => {
      const month = Number(container.querySelector('#sf-month')?.value);
      const amount = Number(container.querySelector('#sf-amount')?.value);
      const note = container.querySelector('#sf-note')?.value || '';
      if (month > 0 && amount > 0) {
        state.addSnowflake(month, amount, note);
        render();
      }
    });

    container.querySelectorAll('[data-remove-sf]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.removeSnowflake(e.target.dataset.removeSf);
        render();
      });
    });

    // Strategy comparison switch
    container.querySelectorAll('[data-switch-strategy]').forEach(btn => {
      btn.addEventListener('click', e => {
        state.set('strategy', e.currentTarget.dataset.switchStrategy);
        activeTab = 'overview';
        render();
      });
    });

    // Settings
    container.querySelectorAll('input[name="strategy"]').forEach(inp => {
      inp.addEventListener('change', e => {
        state.set('strategy', e.target.value);
        render();
      });
    });

    const settingsFields = {
      '#ef-balance': (v) => state.set('efBalance', Number(v)),
      '#ef-pct': (v) => state.set('efMonthlyPct', Number(v) / 100),
      '#invest-split': (v) => state.set('investSplit', Number(v) / 100),
      '#invest-return': (v) => state.set('investReturnPct', Number(v)),
      '#savings-return': (v) => state.set('savingsReturnPct', Number(v)),
      '#proj-years': (v) => state.set('projectionYears', Number(v)),
    };

    Object.entries(settingsFields).forEach(([sel, fn]) => {
      const el = container.querySelector(sel);
      if (el) {
        el.addEventListener('change', e => { fn(e.target.value); render(); });
      }
    });

    // Export
    container.querySelector('#btn-export')?.addEventListener('click', () => {
      const blob = new Blob([state.exportJSON()], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `debt-free-plan-${new Date().toISOString().slice(0,10)}.json`;
      a.click();
    });

    // Import
    container.querySelector('#import-file')?.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = ev => {
        if (state.importJSON(ev.target.result)) {
          render();
        } else {
          alert('Invalid plan file.');
        }
      };
      reader.readAsText(file);
    });
  }

  function scoreColor(score) {
    if (score >= 70) return '#10B981';
    if (score >= 45) return '#F59E0B';
    return '#EF4444';
  }

  render();
}
