// format.js — Currency, date, and number formatting

const CURRENCIES = {
  ZAR: { symbol: 'R', locale: 'en-ZA', code: 'ZAR' },
  USD: { symbol: '$', locale: 'en-US', code: 'USD' },
  GBP: { symbol: '£', locale: 'en-GB', code: 'GBP' },
  EUR: { symbol: '€', locale: 'de-DE', code: 'EUR' },
  KES: { symbol: 'KSh', locale: 'sw-KE', code: 'KES' },
  NGN: { symbol: '₦', locale: 'en-NG', code: 'NGN' },
  GHS: { symbol: 'GH₵', locale: 'en-GH', code: 'GHS' },
};

export function getCurrencies() {
  return CURRENCIES;
}

export function formatCurrency(amount, currencyCode = 'ZAR') {
  const curr = CURRENCIES[currencyCode] || CURRENCIES.ZAR;
  const abs = Math.abs(amount);
  const formatted = abs.toLocaleString(curr.locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const sign = amount < 0 ? '-' : '';
  return `${sign}${curr.symbol} ${formatted}`;
}

export function formatCurrencyCompact(amount, currencyCode = 'ZAR') {
  const curr = CURRENCIES[currencyCode] || CURRENCIES.ZAR;
  const abs = Math.abs(amount);
  let formatted;
  if (abs >= 1_000_000) {
    formatted = `${(abs / 1_000_000).toFixed(1)}M`;
  } else if (abs >= 1_000) {
    formatted = `${(abs / 1_000).toFixed(0)}k`;
  } else {
    formatted = abs.toFixed(0);
  }
  const sign = amount < 0 ? '-' : '';
  return `${sign}${curr.symbol}${formatted}`;
}

export function formatPercent(value, decimals = 1) {
  return `${value.toFixed(decimals)}%`;
}

export function formatMonths(months) {
  if (months <= 0) return '0 months';
  const y = Math.floor(months / 12);
  const m = months % 12;
  const parts = [];
  if (y > 0) parts.push(`${y} yr${y !== 1 ? 's' : ''}`);
  if (m > 0) parts.push(`${m} mo${m !== 1 ? 's' : ''}`);
  return parts.join(' ');
}

export function addMonths(date, months) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}

export function formatMonthYear(date) {
  return date.toLocaleDateString('en-ZA', { month: 'short', year: 'numeric' });
}

export function monthYearFromOffset(offsetMonths) {
  return formatMonthYear(addMonths(new Date(), offsetMonths));
}

export function getMonthName(offsetMonths) {
  return addMonths(new Date(), offsetMonths).toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' });
}

export function generateId() {
  return `id_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function round2(n) {
  return Math.round(n * 100) / 100;
}
