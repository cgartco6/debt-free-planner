// budgetEngine.js — Income, expense analysis, surplus calculation, health scoring

export const EXPENSE_CATEGORIES = {
  housing:        { label: 'Housing',            icon: '🏠', type: 'fixed' },
  transport:      { label: 'Transport',          icon: '🚗', type: 'fixed' },
  food:           { label: 'Food & Groceries',   icon: '🛒', type: 'variable' },
  utilities:      { label: 'Utilities',          icon: '💡', type: 'fixed' },
  insurance:      { label: 'Insurance',          icon: '🛡️', type: 'fixed' },
  subscriptions:  { label: 'Subscriptions',      icon: '📱', type: 'variable' },
  childcare:      { label: 'Childcare / School', icon: '👶', type: 'fixed' },
  medical:        { label: 'Medical / Health',   icon: '❤️', type: 'variable' },
  clothing:       { label: 'Clothing',           icon: '👕', type: 'discretionary' },
  entertainment:  { label: 'Entertainment',      icon: '🎬', type: 'discretionary' },
  personal:       { label: 'Personal Care',      icon: '💅', type: 'discretionary' },
  savings:        { label: 'Existing Savings',   icon: '🏦', type: 'savings' },
  other:          { label: 'Other',              icon: '📦', type: 'variable' },
};

/**
 * Aggregate multiple income sources into a single monthly net figure.
 * Handles irregular income by optionally using a 3-month average.
 * @param {Array} sources - [{ amount: number, isIrregular: bool, months: [n,n,n] }]
 */
export function calculateMonthlyIncome(sources) {
  return sources.reduce((total, src) => {
    if (src.isIrregular && src.months && src.months.length) {
      const avg = src.months.reduce((s, v) => s + Number(v), 0) / src.months.length;
      return total + avg;
    }
    return total + Number(src.amount || 0);
  }, 0);
}

/**
 * Calculate total monthly expenses, broken down by category type.
 * @param {Array} expenses - [{ category: string, name: string, amount: number }]
 */
export function analyzeExpenses(expenses) {
  const totals = { fixed: 0, variable: 0, discretionary: 0, savings: 0, total: 0 };
  const byCategory = {};

  expenses.forEach(exp => {
    const amount = Number(exp.amount || 0);
    const catMeta = EXPENSE_CATEGORIES[exp.category] || { type: 'variable' };
    totals[catMeta.type] = (totals[catMeta.type] || 0) + amount;
    totals.total += amount;
    byCategory[exp.category] = (byCategory[exp.category] || 0) + amount;
  });

  return { totals, byCategory };
}

/**
 * Calculate the true monthly surplus available for debt + savings work.
 * @param {number} income - Net monthly income
 * @param {Array} expenses - Expense items
 * @param {Array} debts - Debt items (to extract minimum payments)
 */
export function calculateSurplus(income, expenses, debts) {
  const { totals } = analyzeExpenses(expenses);
  const totalMinimums = debts.reduce((s, d) => s + Number(d.minPayment || 0), 0);
  const totalExpenses = totals.total;
  const surplusBeforeDebt = income - totalExpenses;
  const surplusAfterMinimums = surplusBeforeDebt - totalMinimums;

  return {
    income,
    totalExpenses,
    totalMinimums,
    surplusBeforeDebt,
    surplusAfterMinimums, // THIS is what attacks debt
    isDeficit: surplusBeforeDebt < 0,
    cannotCoverMinimums: surplusAfterMinimums < 0,
  };
}

/**
 * Compute a 0-100 Freedom Score reflecting overall financial health.
 * NOT a credit score. Measures distance from debt freedom.
 */
export function calcFreedomScore(income, expenses, debts, efBalance = 0) {
  if (!income) return 0;
  const { totals } = analyzeExpenses(expenses);
  const totalDebt = debts.reduce((s, d) => s + Number(d.balance || 0), 0);
  const totalMin = debts.reduce((s, d) => s + Number(d.minPayment || 0), 0);
  const surplus = income - totals.total;
  const monthlyExpenses = totals.total;

  // Component 1: Surplus ratio (40 pts) — how much breathing room exists
  const surplusRatio = surplus / income;
  const surplusScore = clamp(surplusRatio * 100 * 1.2, 0, 40);

  // Component 2: Debt-to-annual-income (30 pts) — lower is better
  const dti = totalDebt / (income * 12);
  const debtScore = clamp(30 - dti * 15, 0, 30);

  // Component 3: Emergency fund coverage (20 pts)
  const efMonths = monthlyExpenses > 0 ? efBalance / monthlyExpenses : 0;
  const efScore = clamp(efMonths * 4, 0, 20);

  // Component 4: Minimum payments as % of income (10 pts) — lower is better
  const minRatio = income > 0 ? totalMin / income : 1;
  const minScore = clamp(10 - minRatio * 20, 0, 10);

  return Math.round(surplusScore + debtScore + efScore + minScore);
}

function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

/**
 * Generate actionable budget insight messages (non-judgmental).
 * Returns a list of { type: 'info'|'warning'|'critical', message: string }
 */
export function generateBudgetInsights(income, expenses, debts) {
  const { totals, byCategory } = analyzeExpenses(expenses);
  const totalDebt = debts.reduce((s, d) => s + Number(d.balance || 0), 0);
  const totalMin = debts.reduce((s, d) => s + Number(d.minPayment || 0), 0);
  const surplus = income - totals.total;
  const surplusAfterMin = surplus - totalMin;
  const insights = [];

  if (surplus < 0) {
    insights.push({
      type: 'critical',
      title: 'Expenses exceed income',
      message: `Your monthly expenses exceed income by ${Math.abs(surplus).toFixed(0)}. Before attacking debt, review which expense categories can be reduced.`,
    });
  }

  if (surplusAfterMin < 0 && surplus >= 0) {
    insights.push({
      type: 'critical',
      title: 'Minimum payments at risk',
      message: `Minimum debt payments (${totalMin.toFixed(0)}) exceed your surplus (${surplus.toFixed(0)}). Missing minimums triggers fees and rate increases. Prioritise trimming variable expenses first.`,
    });
  }

  if (surplusAfterMin > 0 && surplusAfterMin < income * 0.05) {
    insights.push({
      type: 'warning',
      title: 'Very thin extra margin',
      message: `After minimums, you have ${surplusAfterMin.toFixed(0)}/mo to accelerate payoff. Any reduction in variable expenses directly speeds up your freedom date.`,
    });
  }

  const housingRatio = (byCategory.housing || 0) / income;
  if (housingRatio > 0.35) {
    insights.push({
      type: 'warning',
      title: 'Housing above 35% of income',
      message: `Housing is consuming ${(housingRatio * 100).toFixed(0)}% of your income. The target range is 25–30%. If renting, consider whether a move is feasible. This single change has the biggest impact.`,
    });
  }

  const discRatio = (totals.discretionary || 0) / income;
  if (discRatio > 0.15 && surplusAfterMin < income * 0.1) {
    insights.push({
      type: 'info',
      title: 'Discretionary spending opportunity',
      message: `Discretionary categories (entertainment, clothing, personal care) total ${(discRatio * 100).toFixed(0)}% of income. Trimming this by 30% would free up ~${(totals.discretionary * 0.3).toFixed(0)}/mo for debt.`,
    });
  }

  if (surplusAfterMin >= income * 0.15) {
    insights.push({
      type: 'success',
      title: 'Strong attack budget',
      message: `Your ${surplusAfterMin.toFixed(0)}/mo attack budget is healthy. Staying consistent is the only thing standing between you and debt freedom.`,
    });
  }

  return insights;
}
