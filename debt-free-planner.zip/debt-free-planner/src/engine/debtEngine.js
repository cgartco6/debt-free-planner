// debtEngine.js — Core debt payoff algorithms with payment roll (cascade) logic

/**
 * Strategy definitions
 */
export const STRATEGIES = {
  avalanche: {
    label: 'Avalanche',
    tagline: 'Highest interest rate first',
    description: 'Mathematically optimal. Minimises total interest paid. Best if you stay consistent.',
    sort: (debts) => [...debts].sort((a, b) => b.apr - a.apr),
  },
  snowball: {
    label: 'Snowball',
    tagline: 'Lowest balance first',
    description: 'Pays off accounts fastest. Builds momentum through quick wins. Best if you need motivation.',
    sort: (debts) => [...debts].sort((a, b) => a.balance - b.balance),
  },
  hybrid: {
    label: 'Hybrid',
    tagline: 'Balanced: interest + psychology',
    description: 'Prioritises high-interest debts but targets a quick win every 6-9 months. Best of both worlds.',
    sort: (debts) => {
      // Score: 60% apr rank + 40% inverse balance rank
      const byApr = [...debts].sort((a, b) => b.apr - a.apr);
      const byBal = [...debts].sort((a, b) => a.balance - b.balance);
      return [...debts].sort((a, b) => {
        const scoreA = byApr.indexOf(a) * 0.6 + byBal.indexOf(a) * 0.4;
        const scoreB = byApr.indexOf(b) * 0.6 + byBal.indexOf(b) * 0.4;
        return scoreA - scoreB;
      });
    },
  },
};

/**
 * Calculate a complete month-by-month debt payoff schedule.
 *
 * @param {Array} debts - [{ id, name, balance, apr, minPayment, type }]
 * @param {number} extraMonthly - Extra money available beyond all minimums
 * @param {string} strategy - 'avalanche' | 'snowball' | 'hybrid'
 * @param {Array} snowflakes - Optional one-off payments [{ month: number, amount: number }]
 * @returns {Object} Full schedule, milestones, totals
 */
export function calculateSchedule(debts, extraMonthly, strategy = 'avalanche', snowflakes = []) {
  if (!debts || debts.length === 0) {
    return { schedule: [], milestones: [], totalMonths: 0, totalInterest: 0, payoffSequence: [] };
  }

  const strat = STRATEGIES[strategy] || STRATEGIES.avalanche;

  // Deep copy + normalise debts
  let active = debts.map(d => ({
    id: d.id,
    name: d.name,
    type: d.type || 'other',
    balance: Math.round(Number(d.balance) * 100) / 100,
    apr: Number(d.apr),
    minPayment: Math.round(Number(d.minPayment) * 100) / 100,
    originalBalance: Number(d.balance),
    totalInterestPaid: 0,
    totalPrincipalPaid: 0,
    paid: false,
    paidMonth: null,
  }));

  const schedule = [];
  const milestones = [];
  const payoffSequence = [];
  let rollingExtra = Math.max(0, Number(extraMonthly));
  let month = 0;
  const MAX_MONTHS = 600; // 50-year safety cap

  while (active.some(d => !d.paid) && month < MAX_MONTHS) {
    month++;

    // Check for snowflake (one-off extra payment this month)
    const snowflake = snowflakes.find(s => s.month === month);
    const snowflakeAmount = snowflake ? Number(snowflake.amount) : 0;

    // Determine this month's target (first non-paid in strategy order)
    const eligible = strat.sort(active.filter(d => !d.paid));
    const target = eligible[0];

    const monthDebts = [];
    let monthTotalInterest = 0;
    let monthTotalPrincipal = 0;

    active.forEach(debt => {
      if (debt.paid) {
        monthDebts.push({ ...debt, payment: 0, interest: 0, principal: 0, isTarget: false });
        return;
      }

      const monthlyRate = debt.apr / 100 / 12;
      const interest = Math.round(debt.balance * monthlyRate * 100) / 100;
      const isTarget = debt.id === target.id;

      // Payment = minimum + extra (if target) + snowflake (if target)
      const rawPayment = isTarget
        ? debt.minPayment + rollingExtra + snowflakeAmount
        : debt.minPayment;

      // Cannot pay more than balance + interest
      const maxPayment = Math.round((debt.balance + interest) * 100) / 100;
      const payment = Math.min(rawPayment, maxPayment);
      const principal = Math.round((payment - interest) * 100) / 100;

      debt.balance = Math.round((debt.balance - principal) * 100) / 100;
      if (debt.balance < 0.01) debt.balance = 0;

      debt.totalInterestPaid += interest;
      debt.totalPrincipalPaid += principal;

      monthTotalInterest += interest;
      monthTotalPrincipal += principal;

      monthDebts.push({
        id: debt.id,
        name: debt.name,
        balance: debt.balance,
        payment,
        interest,
        principal,
        isTarget,
        apr: debt.apr,
      });

      // Debt paid off?
      if (debt.balance <= 0) {
        debt.paid = true;
        debt.paidMonth = month;

        milestones.push({
          month,
          type: 'debt_paid',
          debtId: debt.id,
          debtName: debt.name,
          freedPayment: debt.minPayment,
          originalBalance: debt.originalBalance,
          totalInterestPaid: debt.totalInterestPaid,
          rollingExtraAfter: rollingExtra + debt.minPayment,
        });

        payoffSequence.push({
          id: debt.id,
          name: debt.name,
          paidMonth: month,
          originalBalance: debt.originalBalance,
          totalInterestPaid: debt.totalInterestPaid,
          freedPayment: debt.minPayment,
        });

        // THE ROLL: freed minimum joins the attack budget
        rollingExtra += debt.minPayment;
      }
    });

    schedule.push({
      month,
      debts: monthDebts,
      totalInterest: monthTotalInterest,
      totalPrincipal: monthTotalPrincipal,
      snowflake: snowflakeAmount,
      rollingExtra,
    });

    if (active.every(d => d.paid)) break;
  }

  const totalInterest = active.reduce((s, d) => s + d.totalInterestPaid, 0);
  const totalPrincipal = active.reduce((s, d) => s + d.totalPrincipalPaid, 0);

  return {
    schedule,
    milestones,
    payoffSequence,
    totalMonths: month,
    totalInterest: Math.round(totalInterest * 100) / 100,
    totalPrincipal: Math.round(totalPrincipal * 100) / 100,
    debtFreeMonth: month,
  };
}

/**
 * Compare all three strategies side by side.
 * @returns {Object} { avalanche, snowball, hybrid }
 */
export function compareStrategies(debts, extraMonthly) {
  return {
    avalanche: calculateSchedule(debts, extraMonthly, 'avalanche'),
    snowball:  calculateSchedule(debts, extraMonthly, 'snowball'),
    hybrid:    calculateSchedule(debts, extraMonthly, 'hybrid'),
  };
}

/**
 * Calculate what happens if minimums-only are paid (worst case baseline).
 */
export function minimumsOnlySchedule(debts) {
  return calculateSchedule(debts, 0, 'avalanche');
}

/**
 * Calculate how many months are saved by adding extra monthly payment.
 */
export function monthsSavedByExtra(debts, extraAmount, strategy = 'avalanche') {
  const base = calculateSchedule(debts, 0, strategy);
  const withExtra = calculateSchedule(debts, extraAmount, strategy);
  return {
    monthsSaved: base.totalMonths - withExtra.totalMonths,
    interestSaved: base.totalInterest - withExtra.totalInterest,
    base,
    withExtra,
  };
}

/**
 * Get the month-by-month balance for a specific debt (for charting).
 */
export function getDebtBalanceSeries(schedule, debtId) {
  return schedule.map(m => {
    const d = m.debts.find(x => x.id === debtId);
    return d ? d.balance : 0;
  });
}

/**
 * Get total remaining debt per month (for charting).
 */
export function getTotalDebtSeries(schedule) {
  return schedule.map(m =>
    m.debts.reduce((s, d) => s + (d.balance || 0), 0)
  );
}
