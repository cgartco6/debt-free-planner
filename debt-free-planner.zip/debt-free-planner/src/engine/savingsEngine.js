// savingsEngine.js — Post-debt savings and wealth projection engine

/**
 * Project savings/investment growth using compound interest with monthly contributions.
 * Uses the standard future value of annuity formula:
 *   FV = P * ((1 + r)^n - 1) / r + PV * (1 + r)^n
 *
 * @param {number} monthlyContribution - Amount added per month
 * @param {number} initialBalance - Starting balance
 * @param {number} annualReturnPct - Annual return percentage (e.g. 8 for 8%)
 * @param {number} years - Number of years to project
 * @returns {Array} Year-by-year projection [{year, balance, contributed, growth}]
 */
export function projectGrowth(monthlyContribution, initialBalance = 0, annualReturnPct = 8, years = 20) {
  const monthlyRate = annualReturnPct / 100 / 12;
  const projection = [];
  let balance = initialBalance;
  let totalContributed = initialBalance;

  for (let year = 1; year <= years; year++) {
    for (let month = 1; month <= 12; month++) {
      const interest = balance * monthlyRate;
      balance += interest + monthlyContribution;
      totalContributed += monthlyContribution;
    }
    projection.push({
      year,
      balance: Math.round(balance),
      contributed: Math.round(totalContributed),
      growth: Math.round(balance - totalContributed),
      growthPct: totalContributed > 0 ? ((balance - totalContributed) / totalContributed) * 100 : 0,
    });
  }

  return projection;
}

/**
 * Generate a full wealth building timeline from the debt-free date forward.
 * Shows what happens when all former debt payments become investments/savings.
 *
 * @param {number} totalFreedPayments - Total monthly amount freed from debt
 * @param {Object} splits - { investPct: 0.6, savingsPct: 0.4 }
 * @param {Object} rates - { investReturn: 10, savingsReturn: 6 }
 * @param {number} years - Projection horizon
 */
export function generateWealthTimeline(totalFreedPayments, splits = {}, rates = {}, years = 25) {
  const {
    investPct = 0.6,
    savingsPct = 0.4,
  } = splits;

  const {
    investReturn = 10,   // Equities / diversified ETF
    savingsReturn = 6,   // HYSA / money market / bonds
  } = rates;

  const investMonthly = totalFreedPayments * investPct;
  const savingsMonthly = totalFreedPayments * savingsPct;

  const investments = projectGrowth(investMonthly, 0, investReturn, years);
  const savings = projectGrowth(savingsMonthly, 0, savingsReturn, years);

  const combined = investments.map((inv, i) => ({
    year: inv.year,
    investments: inv.balance,
    savings: savings[i].balance,
    total: inv.balance + savings[i].balance,
    contributed: inv.contributed + savings[i].contributed,
    growth: inv.balance + savings[i].balance - (inv.contributed + savings[i].contributed),
  }));

  // Find the milestones
  const milestones = [];
  const targets = [100_000, 250_000, 500_000, 1_000_000, 2_000_000, 5_000_000];
  targets.forEach(target => {
    const hit = combined.find(y => y.total >= target);
    if (hit) milestones.push({ amount: target, year: hit.year });
  });

  return {
    investMonthly,
    savingsMonthly,
    timeline: combined,
    milestones,
    at10Years: combined[9] || null,
    at20Years: combined[19] || null,
    at25Years: combined[24] || null,
  };
}

/**
 * Calculate how much interest was wasted paying minimum payments only
 * vs the chosen strategy. Used for the "cost of doing nothing" display.
 *
 * @param {number} minimumsOnlyInterest
 * @param {number} strategyInterest
 */
export function calcInterestWasted(minimumsOnlyInterest, strategyInterest) {
  return {
    saved: minimumsOnlyInterest - strategyInterest,
    minimumsOnly: minimumsOnlyInterest,
    withStrategy: strategyInterest,
    savingsPct: minimumsOnlyInterest > 0
      ? ((minimumsOnlyInterest - strategyInterest) / minimumsOnlyInterest) * 100
      : 0,
  };
}

/**
 * Simple "what if I add R X more per month" sensitivity table.
 * @param {function} scheduleCalc - Function(extra) => { totalMonths, totalInterest }
 * @param {number} baseExtra - Current extra monthly amount
 * @param {Array} steps - Extra amounts to test (relative to base)
 */
export function sensitivityAnalysis(scheduleCalc, baseExtra, steps = [500, 1000, 2000, 5000]) {
  const base = scheduleCalc(baseExtra);
  return steps
    .filter(s => baseExtra + s !== baseExtra)
    .map(s => {
      const result = scheduleCalc(baseExtra + s);
      return {
        extraAmount: baseExtra + s,
        addedPer月: s,
        totalMonths: result.totalMonths,
        monthsSaved: base.totalMonths - result.totalMonths,
        totalInterest: result.totalInterest,
        interestSaved: base.totalInterest - result.totalInterest,
      };
    });
}
