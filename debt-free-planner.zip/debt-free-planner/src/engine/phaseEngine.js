// phaseEngine.js — Generates the 5-phase debt-freedom roadmap with specific, personalised actions

import { monthYearFromOffset, formatCurrency } from '../utils/format.js';

/**
 * Phase definitions (static meta)
 */
export const PHASE_META = {
  0: {
    id: 0,
    name: 'Foundation',
    emoji: '🧱',
    colorClass: 'phase-0',
    tagline: 'Get organised. Know your numbers exactly.',
    description: 'The first 30 days are about clarity, not sacrifice. You cannot attack a target you cannot see.',
  },
  1: {
    id: 1,
    name: 'Safety Buffer',
    emoji: '🛡️',
    colorClass: 'phase-1',
    tagline: 'Build a small emergency fund to protect your debt plan.',
    description: 'A R1,000–R2,000 buffer prevents unexpected expenses from forcing you to borrow more. This phase runs short while you pay debt minimums.',
  },
  2: {
    id: 2,
    name: 'Debt Attack',
    emoji: '⚔️',
    colorClass: 'phase-2',
    tagline: 'Every rand above minimums hits your target debt.',
    description: 'This is the longest phase. As each debt clears, its payment rolls into the attack on the next. Your attack power grows every time a debt falls.',
  },
  3: {
    id: 3,
    name: 'Recovery & Full Buffer',
    emoji: '🌱',
    colorClass: 'phase-3',
    tagline: 'Debt free. Now build real financial resilience.',
    description: 'Build 3–6 months of living expenses in a separate account. This phase runs alongside wealth building (Phase 4).',
  },
  4: {
    id: 4,
    name: 'Wealth Building',
    emoji: '🚀',
    colorClass: 'phase-4',
    tagline: 'Your old debt payments now build your wealth.',
    description: 'Every rand that used to pay debt now works for you. Compound growth turns your former payments into long-term wealth.',
  },
};

/**
 * Generate the complete phase plan from budget + debt schedule data.
 *
 * @param {Object} budget - { income, totalExpenses, totalMinimums, surplusAfterMinimums }
 * @param {Object} debtSchedule - Result from calculateSchedule()
 * @param {Object} settings - { currency, efTarget, strategy, efMonthlyPct }
 * @returns {Array} phases — each with duration, start/end month, actions, milestones
 */
export function generatePhases(budget, debtSchedule, debts, settings = {}) {
  const {
    currency = 'ZAR',
    efTarget = null,         // null = auto (1 month expenses)
    efMonthlyPct = 0.2,      // 20% of surplus goes to EF during phase 1
    investSplit = 0.6,       // 60% of freed payments to investments post-debt
    savingsSplit = 0.4,      // 40% of freed payments to savings post-debt
  } = settings;

  const fc = (n) => formatCurrency(n, currency);

  const { income, totalExpenses, surplusAfterMinimums } = budget;
  const { payoffSequence, milestones, totalMonths, totalInterest } = debtSchedule;
  const totalDebt = debts.reduce((s, d) => s + Number(d.balance), 0);

  // Emergency fund target: 1 month of expenses (quick buffer) during Phase 1
  // Then full 3 months in Phase 3
  const miniEfTarget = efTarget || Math.max(1000, totalExpenses);
  const fullEfTarget = totalExpenses * 3;

  // Phase 1: Mini EF (runs parallel with paying minimums only)
  // We allocate 20% of surplus-after-minimums to EF until miniEfTarget is hit
  const efMonthly = surplusAfterMinimums > 0 ? surplusAfterMinimums * efMonthlyPct : 0;
  const phase1Duration = miniEfTarget > 0 && efMonthly > 0
    ? Math.ceil(miniEfTarget / efMonthly)
    : 2;

  // Phase 2: Debt Attack (the bulk of the journey)
  // Extra available after Phase 1 starts = surplusAfterMinimums * (1 - efMonthlyPct)
  // But since EF is small, Phase 1 and Phase 2 overlap slightly (attacker uses 80% of surplus)
  const phase2StartMonth = Math.max(1, phase1Duration);
  const phase2EndMonth = phase2StartMonth + totalMonths;

  // Phase 3: Full emergency fund (3 months)
  // Freed payments per month = sum of all minimum payments
  const totalMinimums = debts.reduce((s, d) => s + Number(d.minPayment), 0);
  const fullAttackBudget = surplusAfterMinimums + totalMinimums; // all freed payments
  const efRemainingNeeded = Math.max(0, fullEfTarget - miniEfTarget);
  const phase3Duration = fullAttackBudget > 0 ? Math.ceil(efRemainingNeeded / fullAttackBudget) : 6;

  // Phase 4: Wealth building — runs forever
  const wealthMonthly = fullAttackBudget;
  const investMonthly = wealthMonthly * investSplit;
  const savingsMonthly = wealthMonthly * savingsSplit;

  const phases = [
    // ─── PHASE 0 ────────────────────────────────────────────────
    {
      ...PHASE_META[0],
      startMonth: 0,
      endMonth: 1,
      duration: 1,
      status: 'active', // Always the starting point
      summary: `Know your exact numbers. Set up your systems. Make all minimums this month.`,
      actions: [
        {
          id: 'p0_a1',
          done: false,
          text: `Confirm your net monthly income (take-home after all deductions): ${fc(income)}/mo`,
        },
        {
          id: 'p0_a2',
          done: false,
          text: `List every debt: name, current balance, interest rate, minimum payment. Total debt: ${fc(totalDebt)}`,
        },
        {
          id: 'p0_a3',
          done: false,
          text: `Open a separate bank account for your emergency fund. Label it "EF – Do Not Touch".`,
        },
        {
          id: 'p0_a4',
          done: false,
          text: `Set up debit orders for ALL minimum payments on their due dates to protect your credit record.`,
        },
        {
          id: 'p0_a5',
          done: false,
          text: `Write down your debt-free date: ${monthYearFromOffset(phase2EndMonth)}. Put it somewhere visible.`,
        },
      ],
      milestones: [
        { label: 'Budget baseline documented', month: 1 },
        { label: 'All minimums on debit order', month: 1 },
      ],
    },

    // ─── PHASE 1 ────────────────────────────────────────────────
    {
      ...PHASE_META[1],
      startMonth: 1,
      endMonth: phase1Duration + 1,
      duration: phase1Duration,
      status: 'upcoming',
      summary: `Save ${fc(miniEfTarget)} emergency buffer in ${phase1Duration} month${phase1Duration !== 1 ? 's' : ''} (${fc(efMonthly)}/mo) while paying minimums on all debts.`,
      actions: [
        {
          id: 'p1_a1',
          done: false,
          text: `Transfer ${fc(efMonthly)} to your EF account on payday, every month. Set up a standing order.`,
        },
        {
          id: 'p1_a2',
          done: false,
          text: `Remaining surplus (${fc(surplusAfterMinimums - efMonthly)}/mo) goes to your highest-priority debt as a bonus payment.`,
        },
        {
          id: 'p1_a3',
          done: false,
          text: `EF target: ${fc(miniEfTarget)} (1 month of essential expenses). Once reached, stop contributing here until Phase 3.`,
        },
        {
          id: 'p1_a4',
          done: false,
          text: `Any unexpected income (bonus, refund, gift) this month goes 100% into the EF until target is hit.`,
        },
      ],
      milestones: [
        { label: `Emergency buffer of ${fc(miniEfTarget)} reached`, month: phase1Duration + 1 },
      ],
    },

    // ─── PHASE 2 ────────────────────────────────────────────────
    {
      ...PHASE_META[2],
      startMonth: phase2StartMonth,
      endMonth: phase2EndMonth,
      duration: totalMonths,
      status: 'upcoming',
      summary: `Attack ${debts.length} debt${debts.length !== 1 ? 's' : ''} with ${fc(surplusAfterMinimums)}/mo extra. Each payoff adds that payment to your attack. Debt free: ${monthYearFromOffset(phase2EndMonth)}.`,
      actions: generatePhase2Actions(debts, payoffSequence, surplusAfterMinimums, currency, phase2StartMonth),
      milestones: generatePhase2Milestones(payoffSequence, phase2StartMonth),
      payoffCascade: buildPayoffCascade(debts, payoffSequence, totalMinimums, surplusAfterMinimums, currency),
      totalInterestPaid: totalInterest,
      interestSaved: null, // filled in by compareStrategies
    },

    // ─── PHASE 3 ────────────────────────────────────────────────
    {
      ...PHASE_META[3],
      startMonth: phase2EndMonth,
      endMonth: phase2EndMonth + phase3Duration,
      duration: phase3Duration,
      status: 'upcoming',
      summary: `You're debt-free. Now redirect ${fc(fullAttackBudget)}/mo (your old debt payments) into a 3-month emergency fund (${fc(fullEfTarget)}).`,
      actions: [
        {
          id: 'p3_a1',
          done: false,
          text: `Redirect ALL former debt payments (${fc(fullAttackBudget)}/mo) into your emergency fund account.`,
        },
        {
          id: 'p3_a2',
          done: false,
          text: `Target: ${fc(fullEfTarget)} (3 months of expenses). At ${fc(fullAttackBudget)}/mo this takes ~${phase3Duration} months.`,
        },
        {
          id: 'p3_a3',
          done: false,
          text: `Consider a high-yield savings account or money market fund for this fund to earn 5-8% p/a.`,
        },
        {
          id: 'p3_a4',
          done: false,
          text: `Review your insurance cover. Now that you're debt-free, your risk profile changes — you may need less (or different) cover.`,
        },
      ],
      milestones: [
        { label: `Full emergency fund of ${fc(fullEfTarget)} reached`, month: phase2EndMonth + phase3Duration },
      ],
    },

    // ─── PHASE 4 ────────────────────────────────────────────────
    {
      ...PHASE_META[4],
      startMonth: phase2EndMonth + phase3Duration,
      endMonth: null, // Ongoing
      duration: null,
      status: 'upcoming',
      summary: `${fc(wealthMonthly)}/mo — your former debt payments — now build your future. Split: ${fc(investMonthly)}/mo investments + ${fc(savingsMonthly)}/mo savings.`,
      actions: [
        {
          id: 'p4_a1',
          done: false,
          text: `Open a retirement annuity (RA) or tax-free savings account (TFSA). First ${fc(investMonthly)}/mo goes here.`,
        },
        {
          id: 'p4_a2',
          done: false,
          text: `Remaining ${fc(savingsMonthly)}/mo into a diversified savings/investment account (ETF, unit trusts, or HYSA).`,
        },
        {
          id: 'p4_a3',
          done: false,
          text: `Review your plan annually. As income grows, increase contributions — do not increase lifestyle proportionally.`,
        },
        {
          id: 'p4_a4',
          done: false,
          text: `Congratulations. Every month from here builds generational wealth. You did the hard part.`,
        },
      ],
      milestones: [],
      wealthProjection: {
        monthlyContribution: wealthMonthly,
        investMonthly,
        savingsMonthly,
      },
    },
  ];

  return phases;
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function generatePhase2Actions(debts, payoffSequence, extraMonthly, currency, startMonth) {
  const fc = (n) => formatCurrency(n, currency);
  const actions = [];

  if (payoffSequence.length === 0) return actions;

  const firstTarget = payoffSequence[0];
  const debtObj = debts.find(d => d.id === firstTarget.id);
  const minPay = debtObj ? Number(debtObj.minPayment) : 0;
  const totalFirstPayment = minPay + extraMonthly;

  actions.push({
    id: 'p2_a1',
    done: false,
    text: `This month, pay ${fc(totalFirstPayment)} to "${firstTarget.name}" (${fc(minPay)} minimum + ${fc(extraMonthly)} extra). Pay only minimums on all others.`,
  });

  actions.push({
    id: 'p2_a2',
    done: false,
    text: `When "${firstTarget.name}" is paid off (${monthYearFromOffset(firstTarget.paidMonth)}), do NOT increase your lifestyle spend. Roll its ${fc(firstTarget.freedPayment)}/mo to the next target.`,
  });

  if (payoffSequence.length > 1) {
    actions.push({
      id: 'p2_a3',
      done: false,
      text: `After "${firstTarget.name}", target: "${payoffSequence[1].name}". Your attack grows automatically with each payoff.`,
    });
  }

  actions.push({
    id: 'p2_a4',
    done: false,
    text: `Any bonus, tax refund, or windfall goes 100% to the current target debt. One windfall can cut months off your timeline.`,
  });

  actions.push({
    id: 'p2_a5',
    done: false,
    text: `Do not take on NEW debt during this phase. New debt restarts the clock and costs more than you think.`,
  });

  return actions;
}

function generatePhase2Milestones(payoffSequence, startMonth) {
  return payoffSequence.map((p, i) => ({
    label: `"${p.name}" paid off`,
    month: startMonth + p.paidMonth,
    freedPayment: p.freedPayment,
    order: i + 1,
  }));
}

function buildPayoffCascade(debts, payoffSequence, totalMinimums, extraMonthly, currency) {
  const fc = (n) => formatCurrency(n, currency);
  let rollingAttack = extraMonthly;

  return payoffSequence.map((p, i) => {
    const debtObj = debts.find(d => d.id === p.id);
    const minPay = debtObj ? Number(debtObj.minPayment) : 0;
    const thisMonthPayment = minPay + rollingAttack;
    rollingAttack += minPay;

    return {
      order: i + 1,
      id: p.id,
      name: p.name,
      originalBalance: p.originalBalance,
      totalInterestPaid: p.totalInterestPaid,
      paidMonth: p.paidMonth,
      paidDate: monthYearFromOffset(p.paidMonth),
      freedPayment: p.freedPayment,
      paymentAtTime: thisMonthPayment,
      rollingAfter: rollingAttack,
      isLast: i === payoffSequence.length - 1,
      label: i === payoffSequence.length - 1
        ? `FREEDOM: ${fc(rollingAttack)}/mo is now yours`
        : `Freed ${fc(p.freedPayment)}/mo → rolls into "${payoffSequence[i + 1]?.name}"`,
    };
  });
}
